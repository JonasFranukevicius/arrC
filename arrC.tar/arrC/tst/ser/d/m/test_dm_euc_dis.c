#include <stdio.h>
#include <stdlib.h>
#include "arrc_dv.h"
#include "arrc_dm.h"
#include "arrc_iv.h"
#include "arrc_utils.h"

int main(
	int	argc,
	char	**argv) {
	int	M = 5;
	int	N = 3;

	printf("Testing dm_euc_dis with M = %d N = %d\n", M, N);
	double	* a = malloc(M * M * sizeof(double));
	double	* b = malloc(M * N * sizeof(double));
	double	* c = malloc(M * N * sizeof(double));

	dv_rnd(b, 0, 1, 123, M * N);
	dv_rnd(c, 0, 1, 123, M * N);
	dm_euc_dis(a, b, c, M, N);
	dm_pri(c, M, N);
	dm_pri(b, M, N);
	dm_pri(a, M, M);

	return 0;
}
