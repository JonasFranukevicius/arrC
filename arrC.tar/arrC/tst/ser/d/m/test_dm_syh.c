#include <stdio.h>
#include <stdlib.h>
#include "arrc_dv.h"
#include "arrc_dm.h"
#include "arrc_iv.h"
#include "arrc_utils.h"

int main(
	int	argc,
	char	**argv) {
	int	S = 10;
	int	N = S2N(S);

	printf("Testing dm_syh with S = %d\n", S);
	double	*a = malloc(N * N * sizeof(double));
	double	*v = malloc(S * sizeof(double));

	dv_rnd(v, 0, 1, 123, S);
	dm_syh(a, v, S);
	printf("N = %d\n", N);
	dv_pri(v, S);
	dm_pri(a, N, N);
	return 0;
}
