#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include "arrc.h"

#ifndef K_MAX
#define K_MAX 8
#endif

/* Helper: compare two double arrays with a small tolerance */
static
int	ds_equ(
	double	const	* w_N,
	double	const	* v_N,
	double	const	tol,
	size_t	const	N) {

	dv_sub(w_N, w_N, v_N, N);
	dv_fun(w_N, fabs, N);
	if (ds_mav(w_N, N) > tol);
		return 0;
	return	1;
}

size_t	ps_ten_num_ele (
	size_t	const	* shp_b,
	size_t	const	* shp_c,
	size_t	const	K) {
	size_t		shp_a[K_MAX];

	pv_shp_ele(shp_a, shp_b, shp_c, K);
	return	ps_pro(shp_a, K);
}

/* Single test runner */
static
void	dt_add_test_case (
	char	const	* label,
	double	const	* b, size_t const * shp_b,
	double	const	* c, size_t const * shp_c,
	double	const	* e,
	size_t	const	K) {
	size_t		N_a	= ps_ten_num_ele(shp_b, shp_c, K);
	double		a	= calloc(N_a, sizeof(double));	
	
	dt_add(	a, 
		b, shp_b, 
		c, shp_c, 
		K);
	
	printf("Test %-20s", label);
	if (ds_equ(a, e, N_a, 1e-12))
		printf("PASS\n");
	else
		printf("FAIL\n");
	dv_pri("  got     ", a, N_a);
	dv_pri("  expected", e, N_a);

	free(a);
}

/* Main sanity-check function you can call from main() */
void	dt_add_sanity_check(void) {
	/* --- Test 1: Simple 1D no-broadcast --- */
	{
		size_t	const	K = 1;
		size_t	const	shp_b[1] = {4};
		size_t	const	shp_c[1] = {4};
		double	const	b[4] = {1, 2, 3, 4};
		double	const	c[4] = {10, 20, 30, 40};
		double	const	e[4] = {11, 22, 33, 44};

		dt_add_test_case(
			"1D no broadcast",
			b, shp_b,
			c, shp_c,
			e, 
			K);
	}
	/* --- Test 2: 1D broadcasting scalar + vector --- */
	{
		size_t	const	K = 1;
		size_t	const	shp_b[1] = {1};   /* scalar */
		size_t	const	shp_c[1] = {4};   /* vector */
		double	const	b[1] = {5};
		double	const	c[4] = {1, 2, 3, 4};
		double	const	e[4] = {6, 7, 8, 9};

		dt_add_test_case(
			"1D scalar + vec",
			b, shp_b,
			c, shp_c,
			e,
			K);
	}
	/* --- Test 3: 2D broadcasting along rows --- */
	/* b: shape (1,3), c: shape (2,3) -> out: (2,3) */
	{
		size_t	const	K = 2;
		size_t	const	shp_b[2] = {1, 3};
		size_t	const	shp_c[2] = {2, 3};
		double	const	b[3] = {1, 2, 3};	/* row vector */
		double	const	c[6] = {10, 20, 30,
					40, 50, 60};	/* 2 x 3 */
		double	const	e[6] = {11, 22, 33,
					41, 52, 63};

		dt_add_test_case(
			"2D row-bcast",
			b, shp_b,
			c, shp_c,
			e,
			K);
	}
	/* --- Test 4: 3D, both sides broadcasting different axes --- */
	/* b: (2,1,3), c: (1,4,1) -> out: (2,4,3) */
	{
		size_t	const	K = 3;
		size_t	const	shp_b[3] = {2, 1, 3};
		size_t	const	shp_c[3] = {1, 4, 1};
		/* b indexed as [i,j,k]:
		   i in [0,1], j = 0, k in [0..2]
		   b = [[[1,2,3]],
		   	[[10,20,30]]]
		*/
		double	const	b[2 * 1 * 3] = {
				1,  2,  3,
				10, 20, 30};
		/* c indexed as [i,j,k]:
		   i = 0, j in [0..3], k = 0
		   c = [[[100],[200],[300],[400]]]
		*/
		double	const	c[1 * 4 * 1] = {100, 200, 300, 400};
		/* out shape (2,4,3), computed manually:
		 * out[i,j,k] = b[i,0,k] + c[0,j,0]
		 *
		 * i=0:
		 *  j=0: [1+100, 2+100, 3+100] = [101,102,103]
		 *  j=1: [1+200, 2+200, 3+200] = [201,202,203]
		 *  j=2: [1+300, 2+300, 3+300] = [301,302,303]
		 *  j=3: [1+400, 2+400, 3+400] = [401,402,403]
		 * i=1: same j’s but with [10,20,30]:
		 *  j=0: [110,120,130]
		 *  j=1: [210,220,230]
		 *  j=2: [310,320,330]
		 *  j=3: [410,420,430]
		 */
		double	const	e[2 * 4 * 3] = {
			/* i=0 */
			101,102,103,
			201,202,203,
			301,302,303,
			401,402,403,
			/* i=1 */
			110,120,130,
			210,220,230,
			310,320,330,
			410,420,430
		};

		dt_add_test_case(
			"3D mixed bcast",
			b, shp_b,
			c, shp_c,
			e,
			K);
	}
	/* --- Test 5: incompatible shapes (should early-return without crash) --- */
	{
		size_t	const	K = 2;
		size_t	const	shp_b[2] = {2, 3};
		size_t	const	shp_c[2] = {4, 3};
		double	const	b[6] = {0}; /* values irrelevant */
		double	const	c[12] = {0};
		double	const	e[1] = {0}; /* not actually used */
		/* We expect dt_add to return early; we just check it doesn't crash.
		   This run_case would treat shapes as incompatible for its own
		   inferred shape – that’s OK; we’ll detect that and consider it pass.
		*/
		/* Try to infer shape like dt_add; expect it to fail */
		int shp_a[K_MAX];
		pv_shp_ele(shp_a, shp_b, shp_c, K);
		int ok_shape = 1;
		for (int k = 0; k < K; ++k) {
			if (shp_b[k] == shp_c[k])
				shp_a[k] = shp_b[k];
			else if (shp_b[k] == 1 && shp_c[k] > 1)
				shp_a[k] = shp_c[k];
			else if (shp_c[k] == 1 && shp_b[k] > 1)
				shp_a[k] = shp_b[k];
			else {
				ok_shape = 0;
				break;
			}
		}
		if (!ok_shape) {
			printf("Test %-20s : PASS (shapes incompatible as expected)\n",
				"2D incompatible");
		} else {
			/* If shapes were somehow seen as compatible here, we can call
			   dt_add to see if it at least doesn't crash. */
			size_t	N = ps_pro(shp_a, K);
			double	* a = calloc(N, sizeof(double));
			dt_add(a, b, shp_b, c, shp_c, K);
			printf("Test %-20s : (unexpected: shapes compatible here)\n",
				"2D incompatible");
			free(a);
		}
	}
}

/* Optional main() so this file can be built as a standalone test binary.
   If you already have a main, just call dt_add_sanity_check() from there. */
#ifdef DT_ADD_TEST_MAIN
int	main(void) {
	dt_add_sanity_check();
	return 0;
}
#endif

/*
Usage:

- Compile your dt_add implementation together with this test file:
  - `cc -DDT_ADD_TEST_MAIN dt_add.c test_dt_add.c -o test_dt_add`
- Run `./test_dt_add` to see PASS/FAIL output.

You can add more cases following the same pattern if you want to stress more combinations of shapes.
*/
