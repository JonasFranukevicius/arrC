#include <stdio.h>
#include <stdlib.h>
#include "arrc_dv.h"
#include "arrc_dm.h"
#include "arrc_iv.h"
#include "arrc_utils.h"

int main(
	int	argc,
	char	**argv) {
	int	N = 5;
	int	S = N2S(N);

	printf("Testing dv_syh with N = %d\n", N);
	double	*w = malloc(S * sizeof(double));
	double	*b = malloc(N * N * sizeof(double));

	dv_rnd(b, 0, 1, 123, N * N);
	dv_syh(w, b, N);
	printf("S = %d\n", S);
	dm_pri(b, N, N);
	dv_pri(w, S);
	return 0;
}
