#include <stdio.h>
#include <stdlib.h>

#include "arrc_dv.h"
#include "arrc_iv.h"

int main(
	int	argc,
	char	**argv) {
	int	N = 23;

	printf("Testing dv_shf with N = %d\n", N);
	int	*u = malloc(N * sizeof(int));
	iv_axi(u, N);
	iv_pri(u, N);
	iv_shf(u, N);
	iv_pri(u, N);
	return 0;
}
