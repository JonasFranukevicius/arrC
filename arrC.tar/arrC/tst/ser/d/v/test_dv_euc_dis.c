#include <stdio.h>
#include <stdlib.h>
#include "arrc_dv.h"
#include "arrc_dm.h"
#include "arrc_iv.h"
#include "arrc_utils.h"

int main(
	int	argc,
	char	**argv) {
	int	M = 5;
	int	N = 3;

	printf("Testing dv_euc_dis with M = %d N = %d\n", M, N);
	double	* w = malloc(M * sizeof(double));
	double	* a = malloc(M * N * sizeof(double));
	double	* v = malloc(N * sizeof(double));

	dv_rnd(a, 0, 1, 123, M * N);
	dv_rnd(v, 0, 1, 123, N);
	dv_euc_dis(w, a, v, M, N);
	dv_pri(v, N);
	dm_pri(a, M, N);
	dv_pri(w, M);

	return 0;
}
