#include <stdio.h>
#include <stdlib.h>
#include "mpi_arrc.h"
#include "arrc.h"
#include "mpi_arrc_utils.h"

int main(
	int	argc,
	char	**argv) {
	int	M = 5;
	int	N = 3;
	MPI_Init(&argc, &argv);

	if (mpi_r() == 0)
		printf("Testing mpi_dv_euc_dis with M = %d N = %d\n", M, N);
	double	* w = mpi_dv_mlc(M);
	double	* a = mpi_dm_mlc(M, N);
	double	* v = malloc(N * sizeof(double));

	    dv_rnd(a, 0, 1, 123 + mpi_r(), M_loc * N);
	    dv_rnd(v, 0, 1, 123, N);
	mpi_dv_euc_dis(w, a, v, M, N);
	if (mpi_r() == 0)
		dv_pri(v, N);
	mpi_dm_pri(a, M, N);
	mpi_dv_pri(w, M);

	MPI_Finalize();
	return 0;
}
