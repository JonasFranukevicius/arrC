#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

#include "arrc_dv.h"
#include "arrc_iv.h"
#include "mpi_arrc_dv.h"
#include "mpi_arrc_iv.h"
#include "mpi_arrc_utils.h"

int main(
	int	argc,
	char	**argv) {
	MPI_Init(&argc, &argv);
	int	N = 23;
	int	R = mpi_R();
	int	r = mpi_r();

	if (r == 0)
		printf("Testing mpi_dv_per with N = %d, R = %d\n", N, R);
	// serial
	double	*w_ser = malloc(N * sizeof(double)),
		*v_ser = malloc(N * sizeof(double));
	int	*u_ser = malloc(N * sizeof(int));
	dv_rnd(v_ser, 0, 1, 123, N);
	iv_axi(u_ser, N);
	iv_shf(u_ser, N);
	dv_per(w_ser, v_ser, u_ser, N);
	// mpi
	double	*w_mpi = mpi_dv_mlc(N),
		*v_mpi = mpi_dv_mlc(N);
	int	*u_mpi = mpi_iv_mlc(N);
	    dv_cpy(v_mpi, &v_ser[mpi_l2g(0, N, r, R)], N_loc);
	    iv_cpy(u_mpi, &u_ser[mpi_l2g(0, N, r, R)], N_loc);
	mpi_dv_per(w_mpi, v_mpi, u_mpi, N);
	// print
	if (r == 0)
		dv_pri(w_ser, N);
	mpi_dv_pri(w_mpi, N);

	MPI_Finalize();
	return 0;
}
