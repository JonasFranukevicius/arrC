#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

#include "arrc_dv.h"
#include "arrc_dm.h"
#include "arrc_iv.h"
#include "arrc_utils.h"
#include "mpi_arrc_dv.h"
#include "mpi_arrc_dm.h"
#include "mpi_arrc_utils.h"

/*
How to use:
mpicc -o test_mpi_dv_per test_mpi_dv_per.c \
      /home/jofran/C/projects/arrC/build/.../libarrc.a  # adjust your paths

mpirun -np 4 ./test_mpi_dv_per
*/

int main(
	int	argc,
	char	**argv) {
	MPI_Init(&argc, &argv);
	int	R = mpi_R();
	int	r = mpi_r();
	int	M = 7;
	int	N = 3;

	// serial
	double	*a_ser = malloc(N * M * sizeof(double)),
		*b_ser = malloc(M * N * sizeof(double));
	dv_rnd(b_ser, 0, 1, 123, M * N);
	dm_tra(a_ser, b_ser, M, N);
	// mpi
	double	*a_mpi = mpi_dm_mlc(N, M),
		*b_mpi = mpi_dm_mlc(M, N);
	for (int m = 0; m < M_loc; ++m)
		dv_cpy(&b_mpi[m0], &b_ser[m2g * N], N);
	mpi_dm_tra(a_mpi, b_mpi, M, N);
	// print
	if (r == 0){
		printf("Testing mpi_dm_tra with M = %d N = %d, R = %d\n", M, N, R);
		dm_pri(b_ser, M, N);
		dm_pri(a_ser, N, M);
	}
	mpi_dm_pri(b_mpi, M, N);
	mpi_dm_pri(a_mpi, N, M);

	free(a_ser);
	free(b_ser);
	free(a_mpi);
	free(b_mpi);
	MPI_Finalize();
	return 0;
}
