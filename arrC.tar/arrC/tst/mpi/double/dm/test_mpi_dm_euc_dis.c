#include <stdio.h>
#include <stdlib.h>
#include "mpi_arrc.h"
#include "arrc.h"
#include "mpi_arrc_utils.h"

int main(
	int	argc,
	char	**argv) {
	int	M = 5;
	int	N = 3;
	MPI_Init(&argc, &argv);

	if (mpi_r() == 0)
		printf("Testing mpi_dm_euc_dis with M = %d N = %d\n", M, N);
	double	* a = mpi_dm_mlc(M, M);
	double	* b = mpi_dm_mlc(M, N);
	double	* c = mpi_dm_mlc(M, N);

	    dv_rnd(b, 0, 1, 123 + mpi_r(), M_loc * N);
	    dv_rnd(c, 0, 1, 124 + mpi_r(), M_loc * N);
	mpi_dm_euc_dis(a, b, b, M, N);
	mpi_dm_pri(c, M, N);
	mpi_dm_pri(b, M, N);
	mpi_dm_pri(a, M, M);

	MPI_Finalize();
	return 0;
}
