#include <mpi.h>
#include <stdio.h>
#include "mpi_arrc_utils.h"


int main(
	int	argc,
	char	**argv) {
	MPI_Init(&argc, &argv);
	int	N = 23;
	int	R = mpi_R();
	int	r = mpi_r();

	if (r == 0)
		printf("Testing mpi_l2g with N = %d, R = %d\n", N, R);
	for (int n = 0; n < N_loc; ++n)
		printf("\tr = %d, l = %d, l2g = %d\n",
				r, n, mpi_l2g(n, N, r, R));

	MPI_Finalize();
	return 0;
}
