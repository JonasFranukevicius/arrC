#include <mpi.h>
#include <stdio.h>
#include "mpi_arrc_utils.h"


int main(
	int	argc,
	char	**argv) {
	MPI_Init(&argc, &argv);
	int	N = 23;
	int	R = mpi_R();
	int	r = mpi_r();

	if (r == 0)
		printf("Testing mpi_g2l with N = %d, R = %d\n", N, R);
	for (int n = 0; n < N; ++n)
		printf("\tr = %d, l = %d, g2l = %d\n",
				r, n, mpi_g2l(n, N, R));

	MPI_Finalize();
	return 0;
}
