#include <mpi.h>
#include <stdio.h>
#include "mpi_arrc_utils.h"


int main(
	int	argc,
	char	**argv) {
	MPI_Init(&argc, &argv);
	int	N = 23;
	int	R = mpi_R();
	int	r = mpi_r();

	printf("Testing mpi_G2L with N = %d, L = %d, r = %d, R = %d\n",
			    N, mpi_G2L(N, r, R), r, R);

	MPI_Finalize();
	return 0;
}
