#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include "arrc/mpi_arrc_m.h"

void	CAT(MPI_PREFIX,m_pri)(
	TYPE	const	* restrict a_LN,
	size_t	const	G,
	size_t	const	N) {
	
	if (r == 0) {
		for (int p = 0; p < R; ++p) {
			TYPE	* b_LN = malloc(L_p * N * sizeof(TYPE));
			if (p == 0)
				CAT(PREFIX,v_cpy)(b_LN, a_LN, L * N);
			else
				MPI_Recv(b_LN, L_p * N, MPI_TYPE, p, p, 
					MPI_COMM_WORLD, MPI_STATUS_IGNORE);
			for (size_t l = 0; l < L_p; ++l)
				CAT(PREFIX,v_pri)(b_lN, N);
			free(b_LN);
		} printf("\n");
	} else
		MPI_Send(a_LN, L * N, MPI_TYPE, 0, r, MPI_COMM_WORLD);
		
	MPI_Barrier(MPI_COMM_WORLD);
}
