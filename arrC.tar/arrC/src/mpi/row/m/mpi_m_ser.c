#include <stdlib.h>
#include <stddef.h>
#include "arrc/mpi_arrc_m.h"

void	CAT(MPI_PREFIX,m_ser)(
	TYPE		* restrict a_LN,
	TYPE	const	* restrict b_GN,
	size_t	const	G,
	size_t	const	N) {

	for (size_t l = 0; l < L; ++l)
		CAT(PREFIX,v_cpy)(a_lN, b_gN, N);
}
