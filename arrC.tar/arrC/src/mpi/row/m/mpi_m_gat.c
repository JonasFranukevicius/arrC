#include <mpi.h>
#include <stdlib.h>
#include <stddef.h>
#include "arrc/mpi_arrc_m.h"

void	CAT(MPI_PREFIX,m_gat)(
	TYPE		* restrict a_GN,
	TYPE	const	* restrict b_LN,
	size_t	const	G,
	size_t	const	N) {
	int		* cnt_rec = calloc(R, sizeof(int));
	int		* dsp_rec = calloc(R, sizeof(int));
	
	for (int p = 0; p < R; ++p)
		cnt_rec[p] = mpi_G2L(G, p) * (int)N;
	for (int p = 1; p < R; ++p)
		dsp_rec[p] = dsp_rec[p - 1] + cnt_rec[p - 1];
	MPI_Allgatherv(
		b_LN, (int)(mpi_G2L(G, mpi_r()) * N), MPI_TYPE,
		a_GN, cnt_rec, dsp_rec, MPI_TYPE,
		MPI_COMM_WORLD
	);
	free(cnt_rec);
	free(dsp_rec);
}
