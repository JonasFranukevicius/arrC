#include <stddef.h>
#include "arrc/mpi_arrc_m.h"

void	CAT(MPI_PREFIX,m_sca)(
	TYPE		* restrict a_LN,
	TYPE	const	* restrict b_LN,
	TYPE	const	* restrict u_L,
	size_t	const	G,
	size_t	const	N) {

	for (size_t l = 0; l < L; ++l)
		CAT(PREFIX,v_sca)(a_lN, b_lN, u_l, N);
}
