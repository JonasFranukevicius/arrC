#include <stddef.h>
#include "arrc/mpi_arrc_m.h"

void	CAT(MPI_PREFIX,m_euc_dis)(
	TYPE		* restrict a_LG,
	TYPE	const	* restrict b_LN,
	TYPE	const	* restrict c_LN,
	size_t	const	G,
	size_t	const	N) {
	
	for (size_t l = 0; l < L; ++l)
		CAT(PREFIX,v_euc_dis)(a_lG, b_lN, c_lN, G, N);
}
