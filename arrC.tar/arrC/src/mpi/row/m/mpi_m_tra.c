#include <mpi.h>
#include <stdlib.h>
#include <stddef.h>
#include "arrc/mpi_arrc_m.h"

void	iv_fil(int *, int, size_t);

void	CAT(MPI_PREFIX,m_tra)(
	TYPE		* restrict a_LM,
	TYPE	const	* restrict b_LN,
	size_t	const	M,
	size_t	const	N) {
	int		* cnt_sen = calloc(R, sizeof(int));
	int		* cnt_rec = calloc(R, sizeof(int));
	int		* dsp_sen = calloc(R, sizeof(int));
	int		* dsp_rec = calloc(R, sizeof(int));
	int		* tmp = calloc(R, sizeof(int));

	if (a_LM == b_LN)
		MPI_Abort(MPI_COMM_WORLD, 1);
	// counts
	for (int p = 0; p < R; ++p)
		cnt_sen[p] = mpi_G2L(M, r) * mpi_G2L(N, p);
	for (int p = 0; p < R; ++p)
		cnt_rec[p] = mpi_G2L(M, p) * mpi_G2L(N, r);
	// displacements
	for (int p = 1; p < R; ++p)
		dsp_sen[p] = dsp_sen[p - 1] + cnt_sen[p - 1];
	for (int p = 1; p < R; ++p)
		dsp_rec[p] = dsp_rec[p - 1] + cnt_rec[p - 1];
	int	const
		T_sen = dsp_sen[R - 1] + cnt_sen[R - 1],
		T_rec = dsp_rec[R - 1] + cnt_rec[R - 1];
	// values
	TYPE	*val_sen = malloc(T_sen * sizeof(TYPE)),
		*val_rec = malloc(T_rec * sizeof(TYPE));
	iv_fil(tmp, 0, (size_t)R);
	for (size_t n = 0; n < N; ++n)
		for (size_t l = 0; l < mpi_G2L(M, r); ++l)
			val_sen[
				  dsp_sen[mpi_g2p(n, N)]
				+     tmp[mpi_g2p(n, N)]++
			] = b_ln;
	MPI_Alltoallv(
		val_sen, cnt_sen, dsp_sen, MPI_TYPE,
		val_rec, cnt_rec, dsp_rec, MPI_TYPE,
		MPI_COMM_WORLD);
	// transposing	
	iv_fil(tmp, 0, (size_t)R);
	for (size_t l = 0; l < mpi_G2L(N, r); ++l)
		for (size_t m = 0; m < M; ++m)
			a_lm = val_rec[
				  dsp_rec[mpi_g2p(m, M)]
				+     tmp[mpi_g2p(m, M)]++];
	// Freeing memory
	free(cnt_sen);
	free(cnt_rec);
	free(dsp_sen);
	free(dsp_rec);
	free(tmp);
	free(val_sen);
	free(val_rec);
}
