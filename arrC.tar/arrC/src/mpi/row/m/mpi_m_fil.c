#include <stddef.h>
#include "arrc/mpi_arrc_m.h"

void	CAT(MPI_PREFIX,m_fil)(
	TYPE		* restrict a_LN,
	TYPE	const	* restrict v_L,
	size_t	const	G,
	size_t	const	N) {

	for (size_t l = 0; l < L; ++l)
		CAT(PREFIX,v_fil)(a_lN, v_l, N);
}
