#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include "arrc/mpi_arrc_m.h"

void	CAT(MPI_PREFIX,m_rea_txt)(
	TYPE		* restrict a_LN,
	FILE		* file, 
	size_t	const	G,
	size_t	const	N) {
	
	if (r == 0) {
		for (int p = 0; p < R; ++p) {
			if (p == 0)
				CAT(PREFIX,m_rea_txt)(a_LN, file, L, N);
			else {
				TYPE * b_LN = malloc(L_p * N * sizeof(TYPE));
				CAT(PREFIX,m_rea_txt)(b_LN, file, L_p, N);
				MPI_Send(b_LN, L_p * N, MPI_TYPE,
						p, p, MPI_COMM_WORLD);
				free(b_LN);
			}
		}
	} else	MPI_Recv(
			a_LN, L * N, MPI_TYPE, 
			0, r,
			MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		
	MPI_Barrier(MPI_COMM_WORLD);
}
