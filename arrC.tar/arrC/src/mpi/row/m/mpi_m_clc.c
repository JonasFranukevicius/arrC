#include <stddef.h>
#include <stdlib.h>
#include "arrc/mpi_arrc_m.h"

TYPE	* CAT(MPI_PREFIX,m_clc)(
	size_t	const	G,
	size_t	const	N) {
	
	return	calloc(L * N, sizeof(TYPE));
}
