#include <stddef.h>
#include "arrc/mpi_arrc_m.h"

void	CAT(MPI_PREFIX,m_mul)(
	TYPE		* restrict a_LN,
	TYPE	const	* restrict b_LN,
	TYPE	const	* restrict c_LN,
	size_t	const	G,
	size_t	const	N) {

	CAT(PREFIX,v_mul)(a_LN, b_LN, c_LN, L * N);
}
