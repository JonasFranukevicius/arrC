#include <stddef.h>
#include <stdlib.h>
#include "arrc/mpi_arrc_m.h"

TYPE	* CAT(MPI_PREFIX,m_mlc)(
	size_t	const	G,
	size_t	const	N) {
	
	return	malloc(L * N * sizeof(TYPE));
}
