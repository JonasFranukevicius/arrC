#include <stddef.h>
#include <stdbool.h>
#include "arrc/mpi_arrc_m.h"

void	CAT(MPI_PREFIX,m_ord)(
	size_t		* restrict a_LN,
	TYPE	const	* restrict b_LN,
	bool	const	* restrict ord_L,
	size_t	const	G,
	size_t	const	N) {

	for (size_t l = 0; l < L; ++l)
		CAT(PREFIX,v_ord)(a_lN, b_lN, ord_l, N);
}
