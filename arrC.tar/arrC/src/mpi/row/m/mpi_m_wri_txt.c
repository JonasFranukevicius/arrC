#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include "arrc/mpi_arrc_m.h"

void	CAT(MPI_PREFIX,m_wri_txt)(
	TYPE	const	* restrict a_LN,
	FILE		* file, 
	size_t	const	G,
	size_t	const	N) {

	if (r == 0) {
		for (int p = 0; p < R; ++p)
			if (p == 0)
				for (size_t l = 0; l < L_p; ++l)
					CAT(PREFIX,v_wri_txt)(a_lN, file, N);
			else {
				TYPE *b_LN = malloc(L_p * N * sizeof(TYPE));
				MPI_Recv(
					b_LN, L_p * N, MPI_TYPE,
					p, p,
					MPI_COMM_WORLD, MPI_STATUS_IGNORE);
				for (size_t l = 0; l < L_p; ++l)
					CAT(PREFIX,v_wri_txt)(b_lN, file, N);
				free(b_LN);
			}
		fprintf(file, "\n");
	} else	MPI_Send(
			a_LN, L * N, MPI_TYPE,
			0, r,
			MPI_COMM_WORLD);
	MPI_Barrier(MPI_COMM_WORLD);
}
