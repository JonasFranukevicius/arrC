#include <stddef.h>
#include "arrc/mpi_arrc_m.h"

void	CAT(MPI_PREFIX,m_per)(
	TYPE		* restrict a_LN,
	TYPE	const	* restrict b_LN,
	size_t	const	* restrict c_LN,
	size_t	const	G,
	size_t	const	N) {

	for (size_t l = 0; l < L; ++l)
		CAT(PREFIX,v_per)(a_lN, b_lN, c_lN, N);
}
