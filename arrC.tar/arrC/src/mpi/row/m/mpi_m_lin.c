#include <stddef.h>
#include "arrc/mpi_arrc_m.h"

void	CAT(MPI_PREFIX,m_lin)(
	TYPE		* restrict a_LN,
	TYPE	const	* restrict min_L,
	TYPE	const	* restrict max_L,
	size_t	const	G,
	size_t	const	N) {

	for (size_t l = 0; l < L; ++l)
		CAT(PREFIX,v_lin)(a_lN, min_l, max_l, N);
}
