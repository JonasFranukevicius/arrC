#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include "arrc/mpi_arrc_v.h"

void	CAT(MPI_PREFIX,v_wri_txt)(
	TYPE	const	* restrict w_L,
	FILE		* file,
	size_t	const	G) {
	
	if (r == 0) {
		for (int p = 0; p < R; ++p) {
			TYPE *v_L = malloc(L_p * sizeof(TYPE));
			if (p == 0)
				CAT(PREFIX,v_cpy)(v_L, w_L, L_p);
			else	MPI_Recv(
					v_L, (int)L_p, MPI_TYPE,
					p, p,
					MPI_COMM_WORLD,
					MPI_STATUS_IGNORE);
			for (size_t l = 0; l < L_p; ++l)
				fprintf(file, (p == 0 && l == 0) ? FMT : " " FMT, v_l);
			free(v_L);
		} fprintf(file, "\n");
	} else	MPI_Send(
			w_L, (int)L, MPI_TYPE,
			0, r,
			MPI_COMM_WORLD);
	MPI_Barrier(MPI_COMM_WORLD);
}
