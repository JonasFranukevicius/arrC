#include <stddef.h>
#include <stdlib.h>
#include <mpi.h>
#include "arrc/mpi_arrc_v.h"

void	CAT(MPI_PREFIX,v_gat)(
	TYPE		* restrict w_G,
	TYPE	const	* restrict v_L,
	size_t	const	G) {
	int		* cnt = calloc(R, sizeof(int));
	int		* dis = calloc(R, sizeof(int));

	for (int p = 0; p < R; ++p)
		cnt[p] = L_p;
	for (int p = 1; p < R; ++p)
		dis[p] = dis[p - 1] + cnt[p - 1];
	MPI_Allgatherv(
			v_L, (int)L, MPI_TYPE,
			w_G, cnt, dis, MPI_TYPE,
			MPI_COMM_WORLD);
	free(cnt);
	free(dis);
}
