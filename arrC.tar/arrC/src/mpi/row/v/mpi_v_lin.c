#include <stddef.h>
#include "arrc/mpi_arrc_v.h"

void	CAT(MPI_PREFIX,v_lin)(
	TYPE		* restrict w_L,
	TYPE	const	min,
	TYPE	const	max,
	size_t	const	G) {
	
	CAT(PREFIX,v_fil)(w_L, CAT(PREFIX,s_lin_stp)(min, max, G), L);
	for (size_t l = 0; l < L; ++l)
		w_l *= l2g;
	CAT(PREFIX,v_shi)(w_L, w_L, min, L);
}
