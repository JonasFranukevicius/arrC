#include <stdlib.h>
#include <stddef.h>
#include "arrc/mpi_arrc_v.h"

void	CAT(MPI_PREFIX,v_rnd)(
	TYPE		* restrict w_L,
	TYPE	const	min,
	TYPE	const	max,
	int	const	seed,
	size_t	const	G) {
	
	CAT(PREFIX,v_rnd)(w_L, min, max, seed + r, L);
}
