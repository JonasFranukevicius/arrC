#include <stddef.h>
#include "arrc/mpi_arrc_v.h"

void	CAT(MPI_PREFIX,v_swp)(
	TYPE		* restrict w_L,
	TYPE		* restrict v_L,
	size_t	const	G) {
	
	CAT(PREFIX,v_swp)(w_L, v_L, L);
}
