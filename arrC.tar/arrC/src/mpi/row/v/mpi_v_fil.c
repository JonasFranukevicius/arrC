#include <stddef.h>
#include "arrc/mpi_arrc_v.h"

void	CAT(MPI_PREFIX,v_fil)(
	TYPE		* restrict w_L,
	TYPE	const	beta,
	size_t	const	G) {
	
	CAT(PREFIX,v_fil)(w_L, beta, L);
}
