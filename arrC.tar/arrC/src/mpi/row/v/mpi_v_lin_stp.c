#include <stddef.h>
#include "arrc/mpi_arrc_v.h"

void	CAT(MPI_PREFIX,v_lin_stp)(
	TYPE		* restrict w_L,
	TYPE	const	* min_L,
	TYPE	const	* max_L,
	size_t	const	G,
	size_t	const	N) {
	
	for (size_t l = 0; l < L; ++l)
		w_l = CAT(PREFIX,s_lin_stp)(min_l, max_l, N);
}
