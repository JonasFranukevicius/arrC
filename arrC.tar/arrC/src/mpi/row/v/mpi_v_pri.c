#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include "arrc/mpi_arrc_v.h"

void	CAT(MPI_PREFIX,v_pri)(
	TYPE	const	* restrict w_L,
	size_t	const	G) {
	
	MPI_Barrier(MPI_COMM_WORLD);
	if (r == 0) {
		for (int p = 0; p < R; ++p) {
			TYPE	* v_L = malloc(L_p * sizeof(TYPE));
			if (p == 0)
				CAT(PREFIX,v_cpy)(v_L, w_L, L);
			else {
				MPI_Recv(
					v_L, L_p, MPI_TYPE,
					p, p,
					MPI_COMM_WORLD,
					MPI_STATUS_IGNORE);
//				printf("mpi_v_pri recv r = %d L = %d\n", mpi_r(), L_p);
			}
			for (size_t l = 0; l < L_p; ++l)
				printf((p == 0 && l == 0) ? FMT : " " FMT, v_l);
			free(v_L);
		}
		printf("\n");
	} else {
		MPI_Send(
			w_L, L, MPI_TYPE,
			0, r,
			MPI_COMM_WORLD);
//		printf("mpi_v_pri sent r = %d L = %d\n", mpi_r(), L);
	}
	//MPI_Barrier(MPI_COMM_WORLD);
}
