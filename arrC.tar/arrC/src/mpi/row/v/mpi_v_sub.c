#include <stddef.h>
#include "arrc/mpi_arrc_v.h"

void	CAT(MPI_PREFIX,v_sub)(
	TYPE		* restrict w_L,
	TYPE	const	* restrict v_L,
	TYPE	const	* restrict u_L,
	size_t	const	G) {
	
	CAT(PREFIX,v_sub)(w_L, v_L, u_L, L);
}
