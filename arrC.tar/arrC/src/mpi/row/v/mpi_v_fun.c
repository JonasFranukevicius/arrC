#include <stddef.h>
#include "arrc/mpi_arrc_v.h"

void	CAT(MPI_PREFIX,v_fun)(
	TYPE		* restrict w_L,
	TYPE	const	* restrict v_L,
	TYPE		(*fun)(TYPE const),
	size_t	const	G) {
	
	CAT(PREFIX,v_fun)(w_L, v_L, fun, L);
}
