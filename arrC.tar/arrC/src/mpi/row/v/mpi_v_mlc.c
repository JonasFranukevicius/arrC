#include <stdlib.h>
#include <stddef.h>
#include "arrc/mpi_arrc_v.h"

TYPE	* CAT(MPI_PREFIX,v_mlc)(
	size_t	const	G) {
	return malloc(L * sizeof(TYPE));
}
