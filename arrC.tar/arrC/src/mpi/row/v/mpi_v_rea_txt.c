#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include "arrc/mpi_arrc_v.h"

void	CAT(MPI_PREFIX,v_rea_txt)(
	TYPE		* restrict w_L,
	FILE		* file,
	size_t	const	G) {

	if (r == 0) {
		for (int p = 0; p < R; ++p) {
			TYPE *v_L = malloc(L_p * sizeof(TYPE));
			for (size_t l = 0; l < L_p; ++l)
				if (fscanf(file, FMT, &v_L[l]) != 1)
					//return	mpi_l2g(l, G, p);
			if (p == 0)
				CAT(PREFIX, v_cpy)(w_L, v_L, L_p);
			else	MPI_Send(
					v_L, (int)L_p, MPI_TYPE,
					p, p,
					MPI_COMM_WORLD);
			free(v_L);
		}
	} else	MPI_Recv(
			w_L, (int)L, MPI_TYPE,
			0, r,
			MPI_COMM_WORLD,
			MPI_STATUS_IGNORE);
	MPI_Barrier(MPI_COMM_WORLD);
}
