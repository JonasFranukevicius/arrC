#include <mpi.h>
#include <stdlib.h>
#include <stdio.h>
#include <stddef.h>
#include "arrc/mpi_arrc_v.h"

#define	u2p	mpi_g2p(u_L[l], G)

void	iv_fil(int *, int, size_t);

void	CAT(MPI_PREFIX,v_per)(
	TYPE		* restrict w_L,
	TYPE	const	* restrict v_L,
	size_t	const	* restrict u_L,
	size_t	const	G) {
	int		* cnt_sen = calloc(R, sizeof(int));
	int		* cnt_rec = calloc(R, sizeof(int));
	int		* cnt_tmp = calloc(R, sizeof(int));
	int		* dsp_sen = calloc(R, sizeof(int));
	int		* dsp_rec = calloc(R, sizeof(int));

	if (w_L == v_L)
	    return;
	
	for (size_t l = 0; l < L; ++l)
		cnt_rec[u2p] += 1;
	MPI_Alltoall(
			cnt_rec, 1, MPI_INT,
			cnt_sen, 1, MPI_INT,
			MPI_COMM_WORLD);
	for (int p = 1; p < R; ++p)
		dsp_sen[p] = dsp_sen[p - 1] + cnt_sen[p - 1];
	for (int p = 1; p < R; ++p)
		dsp_rec[p] = dsp_rec[p - 1] + cnt_rec[p - 1];
	// total dimensions
	int	tot_sen = dsp_sen[R - 1] + cnt_sen[R - 1],
		tot_rec = dsp_rec[R - 1] + cnt_rec[R - 1];
	// global indexes
	int	*g_sen = malloc(tot_sen * sizeof(int)),
		*g_rec = malloc(tot_rec * sizeof(int));
	for (size_t l = 0; l < L; ++l)
		g_rec[
			  dsp_rec[u2p]
			+ cnt_tmp[u2p]++
		] = u_L[l];//mpi_g2r(u[n], N, R);
	MPI_Alltoallv(g_rec, cnt_rec, dsp_rec, MPI_INT,
	              g_sen, cnt_sen, dsp_sen, MPI_INT,
	              MPI_COMM_WORLD);
	// values
	TYPE	*v_sen = malloc(tot_sen * sizeof(TYPE)),
		*v_rec = malloc(tot_rec * sizeof(TYPE));
	for (int p = 0; p < R; ++p)
		for (int i = 0; i < cnt_sen[p]; ++i)
			v_sen[dsp_sen[p] + i] =
				v_L[mpi_g2l(
					g_sen[dsp_sen[p] + i],
					G)];
	MPI_Alltoallv(v_sen, cnt_sen, dsp_sen, MPI_TYPE,
	              v_rec, cnt_rec, dsp_rec, MPI_TYPE,
	              MPI_COMM_WORLD);
	// permutation
	iv_fil(cnt_tmp, 0, R);
	for (size_t l = 0; l < L; ++l)
	    	w_L[l] = v_rec[
			  dsp_rec[u2p]
			+ cnt_tmp[u2p]++];
	// Freeing memory
	free(cnt_sen);
	free(cnt_rec);
	free(cnt_tmp);
	free(dsp_sen);
	free(dsp_rec);
	free(g_sen);
	free(g_rec);
	free(v_sen);
	free(v_rec);
}
