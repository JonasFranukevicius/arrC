#include <stddef.h>
#include "arrc/mpi_arrc_v.h"

void	CAT(MPI_PREFIX,v_euc_dis)(
	TYPE		* restrict w_L,
	TYPE	const	* restrict b_LN,
	TYPE	const	* restrict u_N,
	size_t	const	G,
	size_t	const	N) {
	
	for (size_t l = 0; l < L; ++l)
		w_l = CAT(PREFIX,s_euc_dis)(b_lN, u_N, N);
}
