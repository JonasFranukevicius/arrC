#include <stddef.h>
#include "arrc/mpi_arrc_v.h"

void	CAT(MPI_PREFIX,v_rec)(
	TYPE		* restrict w_L,
	TYPE	const	x,
	TYPE	const	* restrict v_L,
	size_t	const	G) {
	
	CAT(PREFIX,v_rec)(w_L, x, v_L, L);
}
