#include <stddef.h>
#include "arrc/mpi_arrc_v.h"

void	CAT(MPI_PREFIX,v_cpy)(
	TYPE		* restrict w_L,
	TYPE	const	* restrict v_L,
	size_t	const	G) {
	
	CAT(PREFIX,v_cpy)(w_L, v_L, L);
}
