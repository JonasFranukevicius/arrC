#include <stddef.h>
#include "arrc/mpi_arrc_v.h"

void	CAT(MPI_PREFIX,v_mii)(
	size_t		* restrict w_L,
	TYPE	const	* restrict a_LN,
	size_t	const	G,
	size_t	const	N) {
	
	for (size_t l = 0; l < L; ++l)
		w_l = CAT(PREFIX,s_mii)(a_lN, N);
}
