#include <stddef.h>
#include "arrc/mpi_arrc_v.h"

void	CAT(MPI_PREFIX,v_shi)(
	TYPE		* restrict w_L,
	TYPE	const	* restrict v_L,
	TYPE	const	beta,
	size_t	const	G) {
	
	CAT(PREFIX,v_shi)(w_L, v_L, beta, L);
}
