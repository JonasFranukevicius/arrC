#include <stdlib.h>
#include <stddef.h>
#include "arrc/mpi_arrc_v.h"

TYPE	* CAT(MPI_PREFIX,v_clc)(
	size_t	const	G) {
	
	return calloc(L, sizeof(TYPE));
}
