#include <stddef.h>
#include "arrc/mpi_arrc_v.h"

void	CAT(MPI_PREFIX,v_sca)(
	TYPE		* restrict w_L,
	TYPE	const	* restrict v_L,
	TYPE	const	alpha,
	size_t	const	G) {
	
	CAT(PREFIX,v_sca)(w_L, v_L, alpha, L);
}
