#include <stddef.h>
#include <mpi.h>
#include "arrc/mpi_arrc_s.h"

TYPE	CAT(MPI_PREFIX,s_dot)(
	TYPE	const	* restrict v_L,
	TYPE	const	* restrict u_L,
	size_t	const	G) {
	TYPE	dot	= CAT(PREFIX,s_dot)(v_L, u_L, L);

	MPI_Allreduce(&dot, &dot, 1, MPI_TYPE, MPI_SUM, MPI_COMM_WORLD);

	return	dot;
}
