#include <stddef.h>
#include <mpi.h>
#include <math.h>
#include "arrc/mpi_arrc_s.h"

TYPE	CAT(MPI_PREFIX,s_euc_nrm)(
	TYPE	const	* restrict v_L,
	size_t	const	G) {
	TYPE		sum = CAT(PREFIX, s_euc_nrm)(v_L, L);
	
	MPI_Allreduce(&sum, &sum, 1, MPI_TYPE,
			MPI_SUM, MPI_COMM_WORLD);
	return	sqrt(sum);
}
