#include <stddef.h>
#include <mpi.h>
#include "arrc/mpi_arrc_s.h"

TYPE	CAT(MPI_PREFIX,s_mav)(
	TYPE	const	* restrict v_L,
	size_t	const	G) {
	size_t		mai = CAT(PREFIX,s_mai)(v_L, L);
	struct { TYPE val; int idx; } max;

	max.val = v_L[mai];		
	max.idx = (int)mpi_l2g(mai, G, r);
	MPI_Allreduce(&max, &max, 1, MPI_TYPE_INT, MPI_MAXLOC, MPI_COMM_WORLD);
	return	max.val;
}
