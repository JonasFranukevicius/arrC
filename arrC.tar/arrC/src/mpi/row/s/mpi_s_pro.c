#include <stddef.h>
#include <mpi.h>
#include "arrc/mpi_arrc_s.h"

TYPE	CAT(MPI_PREFIX,s_pro)(
	TYPE	const	* restrict v_L,
	size_t	const	G) {
	TYPE	pro	= CAT(PREFIX,s_pro)(v_L, L);

	MPI_Allreduce(&pro, &pro, 1, MPI_TYPE, MPI_PROD, MPI_COMM_WORLD);

	return	pro;
}
