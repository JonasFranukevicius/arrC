#include <stddef.h>
#include <mpi.h>
#include <math.h>
#include "arrc/mpi_arrc_s.h"

TYPE	CAT(MPI_PREFIX,s_euc_dis)(
	TYPE	const	* restrict v_L,
	TYPE	const	* restrict u_L,
	size_t	const	G) {
	TYPE		sum = 0;
	
	if (v_L == u_L)
		return	0.0;
	else
		sum = CAT(PREFIX,s_euc_dis)(v_L, u_L, L);
	MPI_Allreduce(&sum, &sum, 1, MPI_TYPE,
			MPI_SUM, MPI_COMM_WORLD);
	return	sqrt(sum);
}
