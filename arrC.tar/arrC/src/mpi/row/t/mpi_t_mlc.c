#include <stddef.h>
#include <stdlib.h>
#include "arrc/mpi_arrc_t.h"

TYPE	* CAT(MPI_PREFIX,t_mlc)(
	size_t	const	* shp,     // global shape
	size_t	const	K,
	size_t	const	dis_axi) {
	size_t		shp_loc[K_MAX];

	pv_shp_loc(shp_loc, shp, K, dis_axi);

	return (TYPE *)malloc(ps_pro(shp_loc, K) * sizeof(TYPE));
}
