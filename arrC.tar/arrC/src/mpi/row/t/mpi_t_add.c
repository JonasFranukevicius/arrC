#include <stddef.h>
#include "arrc/mpi_arrc_t.h"

void	CAT(MPI_PREFIX,t_add)(
	TYPE		* restrict a,
	TYPE	const	* restrict b, const size_t * shp_b, // global
	TYPE	const	* restrict c, const size_t * shp_c, // global
	size_t		K,
	size_t	const	dis_axi) {
	size_t		shp_a[K_MAX];
	size_t		shp_loc_b[K_MAX];
	size_t		shp_loc_c[K_MAX];
	
	pv_shp_loc(shp_loc_b, shp_b, K, dis_axi);
	pv_shp_loc(shp_loc_c, shp_c, K, dis_axi);
	
	CAT(PREFIX,t_add)(
		a,
		b, shp_loc_b,
		c, shp_loc_c,
		K);
}
