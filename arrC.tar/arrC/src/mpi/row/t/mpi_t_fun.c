#include <stddef.h>
#include "arrc/mpi_arrc_t.h"

void	CAT(MPI_PREFIX,t_fun)(
	TYPE		* restrict a,
	TYPE	const	* restrict b, size_t const * shp_b,
	TYPE		(** c)(TYPE), size_t const * shp_c,
	size_t	const	K,
	size_t	const	dis_axi) {
	size_t		shp_loc_b[K_MAX];
	size_t		shp_loc_c[K_MAX];

	pv_shp_loc(shp_loc_b, shp_b, K, dis_axi);
	pv_shp_loc(shp_loc_c, shp_c, K, dis_axi);
	
	CAT(PREFIX,t_fun)(
		a,
		b, shp_loc_b,
		c, shp_loc_c,
		K);
}
