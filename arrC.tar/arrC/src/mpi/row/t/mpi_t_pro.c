#include <mpi.h>
#include <stddef.h>
#include "arrc/mpi_arrc_t.h"

void	CAT(MPI_PREFIX,t_pro)(
	TYPE		* restrict a, const size_t * shp_a, // global
	TYPE	const	* restrict b, const size_t * shp_b, // global
	size_t		K,
	size_t		dis_axi) {
	size_t		shp_loc_a[K_MAX];
	size_t		shp_loc_b[K_MAX];

	pv_shp_loc(shp_loc_a, shp_a, K, dis_axi);
	pv_shp_loc(shp_loc_b, shp_b, K, dis_axi);

	CAT(PREFIX,t_pro)(
		a, shp_loc_a,
		b, shp_loc_b,
		K);

	if (shp_a[dis_axi] == 1 && shp_b[dis_axi] > 1)
		MPI_Allreduce(
			MPI_IN_PLACE,
			a,
			(int)ps_pro(shp_a, K),   // assuming n_global_a fits in int
			MPI_TYPE,
			MPI_PROD,
			MPI_COMM_WORLD);
}
