#include <stddef.h>
#include <mpi.h>
#include "arrc/mpi_arrc_t.h"

void	CAT(MPI_PREFIX,t_dec)(
	TYPE		* restrict a,
	TYPE	const	* restrict b, size_t const * shp_b,
	size_t	const	K,
	size_t	const	dis_axi) {
	size_t		G = shp_b[dis_axi];
	size_t		N = ps_pro(&shp_b[dis_axi + 1], K - dis_axi - 1);
	size_t		O = ps_pro(shp_b, dis_axi);
	TYPE	const	* c = &b[mpi_p2g(mpi_r(), G) * N];

//	printf("r = %d L = %d N = %d O = %d\n", mpi_r(), L, N, O);
	for (size_t o = 0; o < O; ++o) {
//		printf("r = %d o = %d a_i = %d b_i = %d\n",
//			mpi_r(), o, o * L * N, o * G * N + mpi_p2g(mpi_r(), G) * N);
//		fflush(stdout);
//		CAT(PREFIX,v_pri)(&c[o * G * N], L * N);
//		fflush(stdout);
		CAT(PREFIX,v_cpy)(
			&a[o * L * N],
			&c[o * G * N],
			L * N);
	}
//	MPI_Barrier(MPI_COMM_WORLD);
}
