#include <stddef.h>
#include <stdlib.h>
#include "arrc/mpi_arrc_t.h"

void	CAT(MPI_PREFIX,t_gat)(
	TYPE		* restrict a,
	TYPE	const	* restrict b,
	size_t	const	* shp,
	size_t	const	K,
	size_t	const	dis_axi) {
	size_t	const	G = shp[dis_axi];
	//size_t	const	L = mpi_G2L(G, mpi_r());
	size_t	const	N = ps_pro((size_t *)&shp[dis_axi + 1], K - dis_axi - 1);
	size_t	const	O = ps_pro((size_t *)shp, dis_axi);
	int		* cnt_rec = calloc(R, sizeof(int));
	int		* dsp_rec = calloc(R, sizeof(int));
	
	for (int p = 0; p < R; ++p)
		cnt_rec[p] = (int)(mpi_G2L(G, p) * N);
	for (int p = 1; p < R; ++p)
		dsp_rec[p] = dsp_rec[p - 1] + cnt_rec[p - 1];
	for (size_t o = 0; o < O; ++o)
		MPI_Allgatherv(
			&b[o * (L * N)], (int)(L * N), MPI_TYPE,
			&a[o * (G * N)], cnt_rec, dsp_rec, MPI_TYPE,
			MPI_COMM_WORLD);

	free(cnt_rec);
	free(dsp_rec);
}
