#include <stdlib.h>
#include "arrc/arrc_v.h"

void	CAT(PREFIX,v_shi)(
	TYPE 		* restrict w_N,
	TYPE	const	* restrict v_N,
	TYPE	const	beta,
	size_t	const	N) {

	if (w_N == v_N)
		for (size_t n = 0; n < N; ++n)
			w_n += beta;
	else	
		for (size_t n = 0; n < N; ++n)
			w_n = v_n + beta;
}
