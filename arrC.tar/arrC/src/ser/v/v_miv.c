#include <stddef.h>
#include "arrc/arrc_v.h"

void	CAT(PREFIX,v_miv)(
	TYPE 		* restrict w_M,
	TYPE 	const	* restrict a_MN,
	size_t	const	M,
	size_t	const	N) {

	for (size_t m = 0; m < M; ++m)
		w_m = CAT(PREFIX,s_miv)(a_mN, N);
}
