#include <stddef.h>
#include "arrc/arrc_v.h"

void	CAT(PREFIX,v_lin)(
	TYPE 		* restrict w_N,
	TYPE	const	min,
	TYPE	const	max,
	size_t	const	N) {
	
	CAT(PREFIX,v_fil)(w_N, CAT(PREFIX,s_lin_stp)(min, max, N), N);
	for (size_t n = 0; n < N; ++n)
		w_n *= n;
	CAT(PREFIX,v_shi)(w_N, w_N, min, N);
}
