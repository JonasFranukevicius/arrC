#include <stdio.h>
#include "arrc/arrc_v.h"

int	CAT(PREFIX,v_wri_txt)(
	TYPE	const	* restrict w_N,
	FILE		* file,
	size_t	const	N) {

	for (size_t n = 0; n < N; ++n)
		if (fprintf(file, (n == 0) ? FMT : " " FMT, w_N[n]) < 0)
			return (int)n;
	fprintf(file, "\n");
	return (int)N;
}
