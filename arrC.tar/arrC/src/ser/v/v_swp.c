#include <stdlib.h>
#include "arrc/arrc_v.h"

void	CAT(PREFIX,v_swp)(
	TYPE 		* restrict w_N,
	TYPE 		* restrict v_N,
	size_t	const	N) {

	if (w_N != v_N)
		for (size_t n = 0; n < N; ++n)
			CAT(PREFIX,s_swp)(&w_n, &v_n);
}
