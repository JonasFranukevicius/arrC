#include <stddef.h>
#include "arrc/arrc_v.h"

void	CAT(PREFIX,v_cpy)(
	TYPE		* restrict w_N,
	TYPE	const	* restrict v_N,
	size_t	const	N) {

	for (size_t n = 0; n < N; ++n)
		w_n = v_n;
}
