#include <stdlib.h>
#include "arrc/arrc_v.h"

void	CAT(PREFIX,v_sho)(
	TYPE 		* restrict w_N,
	TYPE	const	* restrict v_N,
	TYPE	const	beta,
	size_t	const	N) {

	if (w_N == v_N)
		CAT(PREFIX,v_fil)(w_N, beta, N);
	else	
		for (size_t n = 0; n < N; ++n)
			w_n = beta - v_n;
}
