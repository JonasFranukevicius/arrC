#include <stdbool.h>
#include <stddef.h>
#include "arrc/arrc_v.h"
#include "arrc/arrc_p.h"
// 0 for ascending
// 1 for descending
//void	pv_lin(size_t *w_N, size_t min, size_t max, size_t N);
//void	ps_swp(size_t *alpha, size_t *beta);

void	CAT(PREFIX,v_ord)(
	size_t		* restrict w_N,
	TYPE	const	* restrict v_N,
	bool	const	order,
	size_t	const	N) {
	if (N == 1)
		return;
	pv_lin(w_N, 0, N - 1, N);
	for (size_t i = 0; i < N - 1; ++i)
		for (size_t j = i + 1; j < N; ++j)
			if ((v_wi > v_wj) ^ order)
				ps_swp(&w_i, &w_j);
}
