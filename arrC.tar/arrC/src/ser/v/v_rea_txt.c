#include <stdio.h>
#include "arrc/arrc_v.h"

int	CAT(PREFIX,v_rea_txt)(
	TYPE		* restrict w_N,
	FILE		* file,
	size_t	const	N) {

	for (size_t n = 0; n < N; ++n)
		if (fscanf(file, FMT, &w_N[n]) != 1)
			return n;
	return N;
}
