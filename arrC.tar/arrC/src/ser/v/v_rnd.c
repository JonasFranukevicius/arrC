#include <stdlib.h>
#include "arrc/arrc_v.h"

void	CAT(PREFIX,v_rnd)(
	TYPE 		* restrict w_N,
	TYPE	const	min,
	TYPE	const	max,
	int	const	seed,
	size_t	const	N) {
	srand(seed);

	for (size_t n = 0; n < N; ++n)
		w_n = rand();
	CAT(PREFIX,v_sca)(w_N, w_N, (max - min) / RAND_MAX, N);
	CAT(PREFIX,v_shi)(w_N, w_N, min, N);
}
