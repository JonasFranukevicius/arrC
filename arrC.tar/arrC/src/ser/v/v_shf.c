#include <stdlib.h>
#include "arrc/arrc_v.h"

void	CAT(PREFIX,v_shf)(
	TYPE	* w_N,
	size_t	N) {
	for (size_t n = 0; n < N; ++n)
		CAT(PREFIX,s_swp)(&w_n, &w_N[n + rand() % (N - n)]);
}
