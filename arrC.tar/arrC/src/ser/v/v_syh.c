#include <stdlib.h>
#include <stdio.h>
#include "arrc/arrc_v.h"

void	CAT(PREFIX,v_syh)(
	TYPE		* restrict w_S,
	TYPE	const	* restrict b_N,
	size_t	const	N) {

	for(size_t i = 0; i < N - 1; ++i)
		for(size_t j = i + 1; j < N; ++j)
			w_S[ij2s(i,j,N)] = b_N[i * N + j];
	//for(size_t s = 0; s < N2S(N); ++s)
	//	w_S[s] = b_N[s2ij(s, N)];
}
