#include <stddef.h>
#include "arrc/arrc_v.h"

void	CAT(PREFIX,v_euc_dis)(
	TYPE		* restrict w_M,
	TYPE	const	* restrict b_MN,
	TYPE	const	* restrict u_N,
	size_t	const	M,
	size_t	const	N) {

	for (size_t m = 0; m < M; ++m)
		w_m = CAT(PREFIX,s_euc_dis)(b_mN, u_N, N);
}
