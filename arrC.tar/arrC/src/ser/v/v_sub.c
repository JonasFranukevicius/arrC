#include <stdlib.h>
#include "arrc/arrc_v.h"

void	CAT(PREFIX,v_sub)(
	TYPE 		* restrict w_N,
	TYPE	const	* restrict v_N,
	TYPE	const	* restrict u_N,
	size_t	const	N) {
 
	if (v_N == u_N) 
		CAT(PREFIX,v_fil)(w_N, 0, N);
	else
		if (w_N != v_N && w_N != u_N)
			for (size_t n = 0; n < N; ++n)
				w_n = v_n - u_n;
		else
			if (w_N == v_N)
				for (size_t n = 0; n < N; ++n)
					w_n -= u_n;
			else
				for (size_t n = 0; n < N; ++n)
					w_n = v_n - w_n;
}
