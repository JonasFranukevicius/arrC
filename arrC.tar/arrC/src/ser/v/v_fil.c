#include <stddef.h>
#include "arrc/arrc_v.h"

void	CAT(PREFIX,v_fil)(
	TYPE 		* restrict w_N,
	TYPE	const	beta,
	size_t	const	N) {

	for (size_t n = 0; n < N; ++n)
		w_n = beta;
}
