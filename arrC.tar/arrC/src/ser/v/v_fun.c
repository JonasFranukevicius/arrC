#include <stddef.h>
#include "arrc/arrc_v.h"

void	CAT(PREFIX,v_fun)(
	TYPE 		* restrict w_N,
	TYPE 	const	* restrict v_N,
	TYPE		(*fun)(TYPE const),
	size_t	const	N) {

	if (w_N == v_N)
		for (size_t n = 0; n < N; ++n)
			w_n = fun(w_n);
	else
		for (size_t n = 0; n < N; ++n)
			w_n = fun(v_n);
}
