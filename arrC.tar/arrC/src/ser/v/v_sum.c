#include <stdlib.h>
#include <stddef.h>
#include "arrc/arrc_v.h"

void	CAT(PREFIX,v_sum)(
	TYPE 		* restrict w_M,
	TYPE	const	* restrict b_MN,
	size_t	const	M,
	size_t	const	N) {

	for (size_t m = 0; m < M; ++m)
		w_m = CAT(PREFIX,s_sum)(b_mN, N);
}
