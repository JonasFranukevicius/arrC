#include <stddef.h>
#include "arrc/arrc_v.h"

void	CAT(PREFIX,v_rec)(
	TYPE 		* restrict w_N,
	TYPE	const	x,
	TYPE	const	* restrict v_N,
	size_t	const	N) {
 
	if (w_N == v_N)
		for (size_t n = 0; n < N; ++n)
			w_n = x / w_n;
	else
		for (size_t n = 0; n < N; ++n)
			w_n = x / v_n;
}
