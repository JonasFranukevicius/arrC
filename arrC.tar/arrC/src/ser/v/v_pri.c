#include <stdio.h>
#include <stddef.h>
#include "arrc/arrc_v.h"

void	CAT(PREFIX,v_pri)(
	TYPE	const	* restrict w_N,
	size_t	const	N) {

	for (size_t n = 0; n < N; ++n)
		printf((n == 0) ? FMT : " " FMT, w_n);
	printf("\n");
}
