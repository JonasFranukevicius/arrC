#include <stdbool.h>
#include <stdlib.h>
#include "arrc/arrc_v.h"

static
void	CAT(PREFIX,v_srt_bbl)(
	TYPE 		* restrict w_N,
	bool	const	order,
	size_t	const	N) {

	for (size_t i = 0; i < N; ++i)
		for (size_t j = i + 1; j < N; ++j)
			if ((w_i > w_j) ^ order)
				CAT(PREFIX,s_swp)(&w_i, &w_j);
}

void	CAT(PREFIX,v_srt)(
	TYPE 		* restrict w_N,
	TYPE	const	* restrict v_N,
	bool	const	order,
	size_t	const	N) {

	if (w_N != v_N)
		CAT(PREFIX,v_cpy)(w_N, v_N, N);
	CAT(PREFIX,v_srt_bbl)(w_N, order, N);
}
