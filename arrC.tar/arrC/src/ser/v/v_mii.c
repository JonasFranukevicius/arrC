#include <stddef.h>
#include "arrc/arrc_v.h"

void	CAT(PREFIX,v_mii)(
	size_t		* restrict w_M,
	TYPE	const	* restrict a_MN,
	size_t	const	M,
	size_t	const	N) {

	for (size_t m = 0; m < M; ++m)
		w_m = CAT(PREFIX,s_mii)(a_mN, N);
}
