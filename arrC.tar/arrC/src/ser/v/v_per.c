#include <stddef.h>
#include "arrc/arrc_v.h"

#define	v_un	v_N[u_n]

void	CAT(PREFIX,v_per)(
	TYPE		* restrict w_N,
	TYPE	const	* restrict v_N,
	size_t	const	* restrict u_N,
	size_t	const	N) {

	if (w_N != v_N)
		for (size_t n = 0; n < N; ++n)
			w_n = v_un;
}
