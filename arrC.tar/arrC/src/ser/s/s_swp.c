#include <stddef.h>
#include "arrc/arrc_s.h"

void	CAT(PREFIX,s_swp)(
	TYPE * x,
	TYPE * y){ 
	TYPE	tmp	= *x;
		*x	= *y;
		*y	= tmp;
}
