#include <stdlib.h>
#include "arrc/arrc_s.h"
#include <stdint.h>
#include <stddef.h>

static int64_t	xoshiro256_range_int(int64_t min, int64_t max);
static size_t	xoshiro256_range_size_t(int64_t min, int64_t max);
static double	xoshiro256_range_double(double min, double max);
static float	xoshiro256_range_float(float min, float max);

TYPE	CAT(PREFIX,s_rnd)(
	TYPE	const	min,
	TYPE	const	max) {

	return CAT(xoshiro256_range_,TYPE)(min, max);
	//return ((max - min) / RAND_MAX ) * rand() + min;
}
