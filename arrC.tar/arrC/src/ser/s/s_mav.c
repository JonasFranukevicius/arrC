#include <stddef.h>
#include "arrc/arrc_s.h"

TYPE	CAT(PREFIX,s_mav)(
	TYPE 	const	* restrict v_N,
	size_t	const	N) {
	TYPE		mav = *v_N;

	for (size_t n = 0; n < N; ++n)
		if (v_n > mav)
			mav = v_n;
	return	mav;
}
