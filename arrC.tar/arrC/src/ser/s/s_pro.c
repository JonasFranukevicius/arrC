#include <stddef.h>
#include "arrc/arrc_s.h"

TYPE	CAT(PREFIX,s_pro)(
	TYPE	const	* restrict v_N,
	size_t	const	N) {
	TYPE		pro = 1;

	for (size_t n = 0; n < N; ++n)
		pro *= v_n;
	return	pro;
}
