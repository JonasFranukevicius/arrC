#include <math.h>
#include <stddef.h>
#include "arrc/arrc_s.h"

TYPE CAT(PREFIX,s_euc_dis_sqr)(
	TYPE	const	* restrict v_N,
	TYPE	const	* restrict u_N,
	size_t	const	N) {
	TYPE		sum = 0.0;

	if (v_N == u_N)
		return	0.0;
	for (size_t n = 0; n < N; ++n)
		sum += (v_n - u_n) * (v_n - u_n);
	return	sum;
}
