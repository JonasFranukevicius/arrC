#include <stddef.h>
#include "arrc/arrc_s.h"

size_t	CAT(PREFIX,s_mai)(
	TYPE 	const	* restrict v_N,
	size_t	const	N) {
	size_t		mai = 0;

	for (size_t n = 0; n < N; ++n)
		if (v_n > v_N[mai])
			mai = n;
	return	mai;
}
