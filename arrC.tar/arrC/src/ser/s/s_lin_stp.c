#include <stddef.h>
#include "arrc/arrc_s.h"

TYPE	CAT(PREFIX,s_lin_stp)(
	TYPE	const	miv,
	TYPE	const	mav,
	size_t	const	N) {

	return (mav - miv) / (N - 1);
}
