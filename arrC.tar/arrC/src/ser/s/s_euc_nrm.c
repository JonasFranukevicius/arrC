#include <math.h>
#include <stddef.h>
#include "arrc/arrc_s.h"

TYPE CAT(PREFIX,s_euc_nrm)(
	TYPE	const	* restrict v_N,
	size_t	const	N) {
	TYPE		sum = 0.0;

	for (size_t n = 0; n < N; ++n)
		sum += v_n * v_n;
	return	sqrt(sum);
}
