#include <stddef.h>
#include "arrc/arrc_s.h"

size_t	CAT(PREFIX,s_mii)(
	TYPE 	const	* restrict v_N,
	size_t	const	N) {
	size_t		mii = 0;

	for (size_t n = 0; n < N; ++n)
		if (v_n < v_N[mii])
			mii = n;
	return	mii;
}
