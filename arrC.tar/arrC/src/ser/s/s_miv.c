#include <stddef.h>
#include "arrc/arrc_s.h"

TYPE	CAT(PREFIX,s_miv)(
	TYPE 	const	* restrict v_N,
	size_t	const	N) {
	TYPE		miv = *v_N;

	for (size_t n = 0; n < N; ++n)
		if (v_n < miv)
			miv = v_n;
	return	miv;
}
