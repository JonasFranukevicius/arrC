#include <stddef.h>
#include "arrc/arrc_s.h"

size_t	CAT(PREFIX,s_lin_stp_cnt)(
	TYPE	const	x,
	TYPE	const	miv,
	TYPE	const	mav,
	size_t	const	N) {
	
	if (x >= mav)
		return N - 1;
	return (x - miv) / CAT(PREFIX,s_lin_stp)(miv, mav, N);
}
