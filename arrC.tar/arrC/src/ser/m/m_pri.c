#include <stdio.h>
#include <stddef.h>
#include "arrc/arrc_m.h"

void	CAT(PREFIX,m_pri)(
	TYPE	const	* restrict a_MN,
	size_t	const	M,
	size_t	const	N) {
	
	for (size_t m = 0; m < M; ++m)
		CAT(PREFIX,v_pri)(a_mN, N);
	printf("\n");
}
