#include <stddef.h>
#include "arrc/arrc_m.h"

void	CAT(PREFIX,m_per)(
	TYPE 		* restrict a_MN,
	TYPE	const	* restrict b_MN,
	size_t	const	* restrict c_MN,
	size_t	const	M,
	size_t	const	N) {
	
	for (size_t m = 0; m < M; ++m)
		CAT(PREFIX,v_per)(a_mN, b_mN, c_mN, N);
}
