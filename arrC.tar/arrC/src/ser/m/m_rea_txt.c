#include <stdio.h>
#include <stddef.h>
#include "arrc/arrc_m.h"

int	CAT(PREFIX,m_rea_txt)(
	TYPE		* restrict a_MN,
	FILE		* file,
	size_t	const	M,
	size_t	const	N) {

	for (size_t m = 0; m < M; ++m)
		if (CAT(PREFIX,v_rea_txt)(a_mN, file, N) != N)
			return m;
	return M;
}
