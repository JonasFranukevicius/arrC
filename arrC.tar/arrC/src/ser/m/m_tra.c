#include <stddef.h>
#include "arrc/arrc_m.h"

void	CAT(PREFIX,m_tra)(
	TYPE		* restrict a_NM,
	TYPE	const	* restrict b_MN,
	size_t	const	M,
	size_t	const	N) {

	if (a_NM != b_MN)
		for (size_t m = 0; m < M; ++m)
			for (size_t n = 0; n < N; ++n)
				a_nm = b_mn;
}
