#include <stddef.h>
#include "arrc/arrc_m.h"

void	CAT(PREFIX,m_fil)(
	TYPE		* restrict a_MN,
	TYPE	const	* restrict u_M,
	size_t	const	M,
	size_t	const	N) {

	for (size_t m = 0; m < M; ++m)
		CAT(PREFIX,v_fil)(a_mN, u_m, N);
}
