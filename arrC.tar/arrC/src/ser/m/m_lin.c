#include <stddef.h>
#include "arrc/arrc_m.h"

void	CAT(PREFIX,m_lin)(
	TYPE 		* restrict a_MN,
	TYPE	const	* restrict min_M,
	TYPE	const	* restrict max_M,
	size_t	const	M,
	size_t	const	N) {
	
	for (size_t m = 0; m < M; ++m)
		CAT(PREFIX,v_lin)(a_mN, min_m, max_m, N);
}
