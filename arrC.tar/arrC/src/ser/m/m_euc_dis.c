#include <stddef.h>
#include "arrc/arrc_m.h"

void	CAT(PREFIX,m_euc_dis)(
	TYPE		* restrict a_MM,
	TYPE	const	* restrict b_MN,
	TYPE	const	* restrict c_MN,
	size_t	const	M,
	size_t	const	N) {

	for (size_t m = 0; m < M; ++m)
		CAT(PREFIX,v_euc_dis)(a_mM, b_MN, c_mN, M, N);
}
