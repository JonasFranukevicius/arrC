#include <stddef.h>
#include "arrc/arrc_m.h"

void	CAT(PREFIX,m_ord)(
	size_t 		* restrict a_MN,
	TYPE 	const	* restrict b_MN,
	bool	const	* restrict ord_M,
	size_t	const	M,
	size_t	const	N) {

	for (size_t m = 0; m < M; ++m)
		CAT(PREFIX,v_ord)(a_mN, b_mN, ord_m, N);
}
