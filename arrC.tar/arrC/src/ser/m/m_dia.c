#include <stddef.h>
#include "arrc/arrc_m.h"

void	CAT(PREFIX,m_dia)(
	TYPE		* restrict a_NN,
	TYPE	const	* restrict v_N,
	size_t	const	N) {

	for (size_t n = 0; n < N; ++n)
		a_nn = v_n;
}
