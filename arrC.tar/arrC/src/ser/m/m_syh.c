#include <stddef.h>
#include "arrc/arrc_m.h"

#define	v_s v_S[s]
#define	a_ij	a_NN[s2ij(s, S2N(S))]
#define	a_ji	a_NN[s2ji(s, S2N(S))]

void	CAT(PREFIX,m_syh)(
	TYPE		* restrict a_NN,
	TYPE	const	* restrict v_S,
	size_t	const	S) {

	for(size_t s = 0; s < S; ++s)
		a_ij = a_ji = v_s;
}
