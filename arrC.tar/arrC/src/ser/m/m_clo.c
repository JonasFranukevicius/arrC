#include <stddef.h>
#include "arrc/arrc_m.h"

void	CAT(PREFIX,m_clo)(
	TYPE		* restrict a_MN,
	TYPE	const	* restrict v_N,
	size_t	const	M,
	size_t	const	N) {

	for (size_t m = 0; m < M; ++m)
		CAT(PREFIX,v_cpy)(a_mN, v_N, N);
}
