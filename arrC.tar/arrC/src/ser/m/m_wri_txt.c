#include <stdio.h>
#include <stddef.h>
#include "arrc/arrc_m.h"

int	CAT(PREFIX,m_wri_txt)(
	TYPE	const	* restrict a_MN,
	FILE		* file,
	size_t	const	M,
	size_t	const	N) {
	
	for (size_t m = 0; m < M; ++m)
		if (CAT(PREFIX,v_wri_txt)(a_mN, file, N) != N)
			return (int)m;
	fprintf(file, "\n");
	return (int)M;
}
