#include <stddef.h>
#include "arrc/arrc_m.h"

void	CAT(PREFIX,m_dot)(
	TYPE		* restrict a_MK,
	TYPE	const	* restrict b_MN,
	TYPE	const	* restrict c_NK,
	size_t	const	M,
	size_t	const	N,
	size_t	const	K) {

	for (size_t m = 0; m < M; ++m)
		for (size_t k = 0; k < K; ++k)
			for (size_t n = 0; n < N; ++n)
				a_mk = b_mn * c_nk;
}
