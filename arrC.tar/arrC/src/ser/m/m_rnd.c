#include <stddef.h>
#include "arrc/arrc_m.h"

void	CAT(PREFIX,m_rnd)(
	TYPE 		* restrict a_MN,
	TYPE	const	* restrict min_M,
	TYPE	const	* restrict max_M,
	int	const	seed,
	size_t	const	M,
	size_t	const	N) {
	
	for (size_t m = 0; m < M; ++m)
		CAT(PREFIX,v_rnd)(a_mN, min_m, max_m, seed, N);
}
