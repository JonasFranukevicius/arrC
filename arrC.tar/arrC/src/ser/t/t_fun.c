#include <stddef.h>
#include "arrc/arrc_t.h"

void	CAT(PREFIX,t_fun)(
	TYPE		* restrict a,
	TYPE	const	* restrict b, size_t const * shp_b,
	TYPE	(*const	* restrict c)(TYPE), size_t const * shp_c,
	size_t	const	K) {
	size_t		D = K - 1;
	size_t		N = 1;
	size_t		shp_a[K_MAX];
	size_t		shp_str_a[K_MAX];
	size_t		shp_str_b[K_MAX];
	size_t		shp_str_c[K_MAX];
	size_t		eff_str_b[K_MAX];
	size_t		eff_str_c[K_MAX];
	size_t		idx  [K_MAX] = {0};
	// Initialization
	ini_ele(shp_a, 
		shp_b, 
		shp_c,
		shp_str_a,
		shp_str_b,
		shp_str_c, 
		eff_str_b,
		eff_str_c, 
		K, &D, &N);
	// Branching
	if (eff_str_b[K - 1] == 0)
		if (eff_str_c[K - 1] == 0)
			//	a[n] = f[0](b[0]);
			do	CAT(PREFIX,v_fil)(a, c[0](b[0]), N);
			while	(ele_idx(ele_idx_arg));
		else
			do	for (size_t n = 0; n < N; ++n)
					a[n] = c[n](b[0]);
			//do	CAT(PREFIX,v_sca)(a, f, b[0], N);
			while	(ele_idx(ele_idx_arg));
	else
		if (eff_str_c[K - 1] == 0)
			//	a[n] = f[0](b[n]);
			do	CAT(PREFIX,v_fun)(a, b, c[0], N);
			while	(ele_idx(ele_idx_arg));
		else
			do	for (size_t n = 0; n < N; ++n)
					a[n] = c[n](b[n]);
			//do	CAT(PREFIX,v_mul)(a, b, f, N);
			while	(ele_idx(ele_idx_arg));
}
