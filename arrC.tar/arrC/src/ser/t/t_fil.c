#include <stddef.h>
#include "arrc/arrc_t.h"

void	CAT(PREFIX,t_fil)(
	TYPE		* restrict a, const size_t * shp_a,
	TYPE	const	* restrict b, const size_t * shp_b,
	size_t	const	K) {
	size_t		D = K - 1;
	size_t		N = 1;
	size_t		shp_str_a[K_MAX];
	size_t		shp_str_b[K_MAX]; 
	size_t		eff_str_b[K_MAX];
	size_t		idx  [K_MAX] = {0};
	// Initialization
	ini_fil(shp_a, 
		shp_b, 
		shp_str_a,
		shp_str_b,
		eff_str_b,
		K, &D, &N);
	// Branching
	if (eff_str_b[K - 1] == 0)
		//	a[n] = b[0];
		do	CAT(PREFIX,v_fil)(a, b[0], N);
		while	(fil_idx(fil_idx_arg));
	else
		//	a[n] = b[n];
		do	CAT(PREFIX,v_cpy)(a, b, N);
		while	(fil_idx(fil_idx_arg));
}
