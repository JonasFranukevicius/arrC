#include <stddef.h>
#include "arrc/arrc_t.h"

void	CAT(PREFIX,t_pro)(
	TYPE		* restrict a, const size_t * shp_a,
	TYPE	const	* restrict b, const size_t * shp_b,
	size_t		K) {
	size_t		D;
	size_t		R = 0;
	size_t		N = 1;
	size_t		shp_str_a[K_MAX];
	size_t		shp_str_b[K_MAX];
	size_t		eff_str_b[K_MAX]= {0};
	size_t		idx[K_MAX]	= {0};
	size_t		rdx[K_MAX]	= {0};
	size_t		red[K_MAX];
	// Initialization
	ini_red(	shp_a,
			shp_b,
			shp_str_a,
			shp_str_b,
			eff_str_b,
			red,
			&K, &R, &D, &N);
	// Scalar branch
	if (shp_a[K - 1] == 1)
		do	do	a[0] = CAT(PREFIX,s_pro)(b, N);
			while (red_rdx(red_rdx_arg));
		while (red_idx(red_idx_arg));
	// Vector branch
	else	
		do	do	CAT(PREFIX,v_mul)(a, a, b, N);
			while (red_rdx(red_rdx_arg));
		while (red_idx(red_idx_arg));
}
