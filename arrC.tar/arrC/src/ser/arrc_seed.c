#include <stdlib.h>
#include <stdint.h>
#include <stddef.h>

/* xoshiro256** state: must be non-zero */
static uint64_t 
	s_xoshiro256_state[4] = {
		0x0123456789abcdefULL,
		0xfedcba9876543210ULL,
		0x123456789abcdef0ULL,
		0x0fedcba987654321ULL
	};

static uint64_t splitmix64(uint64_t *x) {
    uint64_t z = (*x += 0x9e3779b97f4a7c15ULL);
    z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
    z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
    return z ^ (z >> 31);
}

static inline uint64_t rotl64(uint64_t x, int k) {
    return (x << k) | (x >> (64 - k));
}

static uint64_t xoshiro256starstar(void) {
    uint64_t *s = s_xoshiro256_state;

    uint64_t const result = rotl64(s[1] * 5ULL, 7) * 9ULL;

    uint64_t const t = s[1] << 17;

    s[2] ^= s[0];
    s[3] ^= s[1];
    s[1] ^= s[2];
    s[0] ^= s[3];

    s[2] ^= t;
    s[3] = rotl64(s[3], 45);

    return result;
}

void arrc_seed(uint64_t seed) {
    uint64_t x = seed;
    for (int i = 0; i < 4; ++i) {
        s_xoshiro256_state[i] = splitmix64(&x);
    }
}

double xoshiro256_double(void) {
    return (xoshiro256starstar() >> 11) * (1.0 / 9007199254740992.0);
}

int64_t xoshiro256_range_int(int64_t min, int64_t max) {
    uint64_t span = (uint64_t)(max - min) + 1u;
    uint64_t x;
    uint64_t limit = UINT64_MAX - (UINT64_MAX % span);
    do {
        x = xoshiro256starstar();
    } while (x > limit);
    return (int64_t)(min + (x % span));
}

size_t xoshiro256_range_size_t(int64_t min, int64_t max) {
    uint64_t span = (uint64_t)(max - min) + 1u;
    uint64_t x;
    uint64_t limit = UINT64_MAX - (UINT64_MAX % span);
    do {
        x = xoshiro256starstar();
    } while (x > limit);
    return (size_t)(min + (x % span));
}

double xoshiro256_range_double(double min, double max) {
    return min + (max - min) * xoshiro256_double();
}

float xoshiro256_range_float(float min, float max) {
    return min + (max - min) * (float)xoshiro256_double();
}
