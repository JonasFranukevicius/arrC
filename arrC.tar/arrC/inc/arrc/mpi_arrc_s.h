#include <stddef.h>
#include "arrc/arrc_macros.h"
#include "arrc/mpi_arrc_utils.h"
#include "arrc/arrc_s.h"

TYPE	CAT(MPI_PREFIX,s_dot)(
	TYPE	const	* restrict v_N,
	TYPE	const	* restrict u_N,
	size_t	const	N);

TYPE	CAT(MPI_PREFIX,s_euc_dis)(
	TYPE	const	* restrict v_N,
	TYPE	const	* restrict u_N,
	size_t	const	N);

TYPE	CAT(MPI_PREFIX,s_euc_nrm)(
	TYPE	const	* restrict v_N,
	size_t	const	N);

TYPE	CAT(MPI_PREFIX,s_lin_stp)(
	TYPE	const	miv,
	TYPE	const	mav,
	size_t	const	N);

size_t	CAT(MPI_PREFIX,s_lin_stp_cnt)(
	TYPE	const	x,
	TYPE	const	miv,
	TYPE	const	mav,
	size_t	const	N);

size_t	CAT(MPI_PREFIX,s_mai)(
	TYPE 	const	* restrict v_N,
	size_t	const	N);

TYPE	CAT(MPI_PREFIX,s_mav)(
	TYPE 	const	* restrict v_N,
	size_t	const	N);

size_t	CAT(MPI_PREFIX,s_mii)(
	TYPE 	const	* restrict v_N,
	size_t	const	N);

TYPE	CAT(MPI_PREFIX,s_miv)(
	TYPE 	const	* restrict v_N,
	size_t	const	N);

TYPE	CAT(MPI_PREFIX,s_pro)(
	TYPE	const	* restrict v_N,
	size_t	const	N);

TYPE	CAT(MPI_PREFIX,s_sum)(
	TYPE	const	* restrict v_N,
	size_t	const	N);

static inline
void	CAT(MPI_PREFIX,s_swp)(
	TYPE * x,
	TYPE * y){ 
	TYPE	tmp	= *x;
		*x	= *y;
		*y	= tmp;
}
