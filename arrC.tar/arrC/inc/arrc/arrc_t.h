#include <stddef.h>
#include <stddef.h>
#include "arrc/arrc_macros.h"

#ifndef	NO_MACROS
#include "arrc/arrc_p.h"
#include "arrc/arrc_m.h"
#define	K_MAX	8
#define	red_rdx_arg	rdx, \
			(void**)&b, \
			sizeof(TYPE), \
			red, \
			shp_b, \
			shp_str_b, \
			R

#define	red_idx_arg	idx, \
			(void**)&a, \
			(void**)&b, \
			sizeof(TYPE), \
			shp_a, \
			shp_str_a, \
			eff_str_b, \
			D

#define	ele_idx_arg	idx, \
			(void**)&a, \
			(void**)&b, \
			(void**)&c, \
			sizeof(TYPE), \
			shp_a, \
			shp_str_a, \
			eff_str_b, \
			eff_str_c, \
			D

#define	fil_idx_arg	idx, \
			(void**)&a, \
			(void**)&b, \
			sizeof(TYPE), \
			shp_a, \
			shp_str_a, \
			eff_str_b, \
			D

static inline
void	pv_shp_str(
	size_t		* str,
	size_t	const	* shp,
	size_t	const	K) {

	str[K - 1] = 1;
	for (size_t k = K - 1; k-- > 0; )
		str[k] = str[k + 1] * shp[k + 1];
}

static inline
void	pv_eff_str(
	size_t		* eff_str,
	size_t	const	* shp,
	size_t	const	* shp_str,
	size_t	const	K) {
	
	for (size_t k = 0; k < K; ++k)
		eff_str[k] = (shp[k] == 1) ? 0 : shp_str[k];
}

static	inline
void	pv_shp_ele(
	size_t		* shp_a,
	size_t	const	* shp_b,
	size_t	const	* shp_c,
	size_t	const	K) {
	
	for (size_t k = 0; k < K; ++k)
		if (shp_b[k] == shp_c[k])
			shp_a[k] = shp_b[k];
		else
			if (shp_b[k] == 1 && shp_c[k] > 1)
				shp_a[k] = shp_c[k];
			else
				if (shp_c[k] == 1 && shp_b[k] > 1)
					shp_a[k] = shp_b[k];
				else
					return;
}

static inline
void	ini_ele(
	size_t		* shp_a,
	size_t	const	* shp_b,
	size_t	const	* shp_c,
	size_t		* shp_str_a,
	size_t		* shp_str_b,
	size_t		* shp_str_c,
	size_t		* eff_str_b,
	size_t		* eff_str_c,
	size_t	const	K,
	size_t		* D,
	size_t		* N) {

	// 1) Infer output shape and check broadcast compatibility
	pv_shp_ele(shp_a, shp_b, shp_c, K);
	// 2) Shape strides for a b and c
	pv_shp_str(shp_str_a, shp_a, K);
	pv_shp_str(shp_str_b, shp_b, K);
	pv_shp_str(shp_str_c, shp_c, K);
	// 3) Effective strides in output index space (0 for broadcast axes)
	pv_eff_str(eff_str_b, shp_b, shp_str_b, K);
	pv_eff_str(eff_str_c, shp_c, shp_str_c, K);
	// 4) Collapse compatible adjacent dimensions
	for (size_t k = K - 1; k > 0; --k)
		if ((eff_str_b[k - 1] == eff_str_b[k] * shp_a[k])
		&&  (eff_str_c[k - 1] == eff_str_c[k] * shp_a[k]))
			(*D)--;
		else
			break;
	// 5) Total elements
	*N = ps_pro(shp_a + *D, K - *D);
}

static	inline
size_t	ele_idx(
	size_t		* idx,		// current multi-index, length D
	void		** a,		// current element pointer in A
	void		** b,		// current element pointer in B
	void		** c,		// current element pointer in C
	size_t	const	size,		// size of one element in bytes
	size_t	const	* shp_a,	// shape of A, length D
	size_t	const	* shp_str_a,	// strides for A in *elements*
	size_t	const	* eff_str_b,	// effective strides for B in elements
	size_t	const	* eff_str_c,	// effective strides for C in elements
	size_t	const	D) {		// number of dimensions
	    		       
	for (size_t d = D; d-- > 0; ) {
		idx[d]++;
		
		*a = (void *)((char *)(*a) + shp_str_a[d] * size);
		*b = (void *)((char *)(*b) + eff_str_b[d] * size);
		*c = (void *)((char *)(*c) + eff_str_c[d] * size);
		
		if (idx[d] < shp_a[d])
		    return 1;
		
		idx[d] = 0;
		
		*a = (void *)((char *)(*a) - shp_str_a[d] * size * shp_a[d]);
		*b = (void *)((char *)(*b) - eff_str_b[d] * size * shp_a[d]);
		*c = (void *)((char *)(*c) - eff_str_c[d] * size * shp_a[d]);
	} return 0;
}

static inline
void	ini_fil(
	size_t		* shp_a,
	size_t	const	* shp_b,
	size_t		* shp_str_a,
	size_t		* shp_str_b,
	size_t		* eff_str_b,
	size_t	const	K,
	size_t		* D,
	size_t		* N) {

	// 1) Shape strides for a and b
	pv_shp_str(shp_str_a, shp_a, K);
	pv_shp_str(shp_str_b, shp_b, K);
	// 2) Effective strides in output index space (0 for broadcast axes)
	pv_eff_str(eff_str_b, shp_b, shp_str_b, K);
	// 3) Collapse compatible adjacent dimensions
	for (size_t k = K - 1; k > 0; --k)
		if ((eff_str_b[k - 1] == eff_str_b[k] * shp_a[k]))
			(*D)--;
		else
			break;
	// 4) Total elements
	*N = ps_pro(shp_a + *D, K - *D);
}

static	inline
size_t	fil_idx(
	size_t		* idx,		// current multi-index, length D
	void		** a,		// current element pointer in A
	void		** b,		// current element pointer in B
	size_t	const	size,		// size of one element in bytes
	size_t	const	* shp_a,	// shape of A, length D
	size_t	const	* shp_str_a,	// strides for A in *elements*
	size_t	const	* eff_str_b,	// effective strides for B in elements
	size_t	const	D) {		// number of dimensions
	    		       
	for (size_t d = D; d-- > 0; ) {
		idx[d]++;
		
		*a = (void *)((char *)(*a) + shp_str_a[d] * size);
		*b = (void *)((char *)(*b) + eff_str_b[d] * size);
		
		if (idx[d] < shp_a[d])
		    return 1;
		
		idx[d] = 0;
		
		*a = (void *)((char *)(*a) - shp_str_a[d] * size * shp_a[d]);
		*b = (void *)((char *)(*b) - eff_str_b[d] * size * shp_a[d]);
	} return 0;
}

#include <stdio.h>

static inline
void	ini_red(
	size_t	const	* shp_a,
	size_t	const	* shp_b,
	size_t		* shp_str_a,
	size_t		* shp_str_b,
	size_t		* eff_str_b,
	size_t		* red,
	size_t		* K,
	size_t		* R,
	size_t		* D,
	size_t		* N) {
	// 1) Collapse redundant dimensions
	while (shp_a[*K - 1] == 1 && shp_b[*K - 1] == 1)
		(*K)--;
	// 2) Calculate strides
	pv_shp_str(shp_str_a, shp_a, *K);
	pv_shp_str(shp_str_b, shp_b, *K);
	// 3) Collapse adjacent dimensions
	if (shp_a[*K - 1] == 1) {
		for (*D = *K; *D > 0; (*D)--)
			if (shp_a[*D - 1] != 1)
				break;
	} else
		for (*D = *K; *D > 0; (*D)--)
			if (shp_b[*D - 1] != shp_a[*D - 1])
				break;
	// 4) Calculate inner loop size
	*N = ps_pro(shp_b + *D, *K - *D);
	// 5) Effective strides for b
	for (size_t k = 0; k < *D; ++k)
		if (shp_a[k] == 1 && shp_b[k] > 1)
			eff_str_b[k] = 0;
		else
			eff_str_b[k] = shp_str_b[k];
	// 6) Build list of reduced axes
	for (size_t k = 0; k < *D; ++k)
		if (eff_str_b[k] == 0)
			red[(*R)++] = k;
}

static inline
size_t	red_idx(
	size_t		* idx,
	void		** a,
	void		** b,
	size_t	const	size,		// size of one element in bytes
	size_t	const	* shp_a,
	size_t	const	* shp_str_a,
	size_t	const	* eff_str_b,
	size_t	const	D) {
	
	for (size_t d = D; d-- > 0; ) {
		idx[d]++;
		
		*a = (void *)((char *)(*a) + shp_str_a[d] * size);
		*b = (void *)((char *)(*b) + eff_str_b[d] * size);
		
		if (idx[d] < shp_a[d])
		    return 1;
		
		idx[d] = 0;
		
		*a = (void *)((char *)(*a) - shp_str_a[d] * size * shp_a[d]);
		*b = (void *)((char *)(*b) - eff_str_b[d] * size * shp_a[d]);
	} return 0;
}

static	inline
size_t	red_rdx(
	size_t		* rdx,
	void		** b,
	size_t	const	size,		// size of one element in bytes
	size_t	const	* red,
	size_t	const	* shp_b,
	size_t	const	* shp_str_b,
	size_t	const	R) {
	
	for (size_t j = R; j-- > 0; ) {
		size_t	ax = red[j];
		rdx[j]++;
		*b = (void *)((char *)(*b) + shp_str_b[ax] * size);
		
		if (rdx[j] < shp_b[ax])
			return 1;

		rdx[j] = 0;
		*b = (void *)((char *)(*b) - shp_str_b[ax] * size * shp_b[ax]);
	} return 0;
}		
#endif	/* NO_MACROS */

void	CAT(PREFIX,t_add)(
	TYPE		* restrict a,
	TYPE	const	* restrict b, const size_t * shp_b,
	TYPE	const	* restrict c, const size_t * shp_c,
	size_t	const	K);

void	CAT(PREFIX,t_div)(
	TYPE		* restrict a,
	TYPE	const	* restrict b, const size_t * shp_b,
	TYPE	const	* restrict c, const size_t * shp_c,
	size_t	const	K);

void	CAT(PREFIX,t_fil)(
	TYPE		* restrict a, const size_t * shp_a,
	TYPE	const	* restrict b, const size_t * shp_b,
	size_t	const	K);

void	CAT(PREFIX,t_fun)(
	TYPE		* restrict a,
	TYPE	const	* restrict b, size_t const * shp_b,
	TYPE	(*const	* restrict c)(TYPE), size_t const * shp_c,
	size_t	const	K);

void	CAT(PREFIX,t_mul)(
	TYPE		* restrict a,
	TYPE	const	* restrict b, const size_t * shp_b,
	TYPE	const	* restrict c, const size_t * shp_c,
	size_t	const	K);

void	CAT(PREFIX,t_pro)(
	TYPE		* restrict a, const size_t * shp_a,
	TYPE	const	* restrict b, const size_t * shp_b,
	size_t		K);

void	CAT(PREFIX,t_sub)(
	TYPE		* restrict a,
	TYPE	const	* restrict b, const size_t * shp_b,
	TYPE	const	* restrict c, const size_t * shp_c,
	size_t	const	K);

void	CAT(PREFIX,t_sum)(
	TYPE		* restrict a, const size_t * shp_a,
	TYPE	const	* restrict b, const size_t * shp_b,
	size_t		K);
