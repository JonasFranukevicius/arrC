#ifndef	ARRC_MACROS_H
#define	ARRC_MACROS_H
#define	CAT2(a,b)	a##b
#define	CAT(a,b)	CAT2(a,b)
#endif	/* ARRC_MACROS_H */
