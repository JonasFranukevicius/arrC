#include <stddef.h>
#include <stdbool.h>
#include <stdio.h>
#include "arrc/arrc_macros.h"
#include "arrc/mpi_arrc_utils.h"
#include "arrc/arrc_m.h"

TYPE	* CAT(MPI_PREFIX,m_clc)(
	size_t	const	G,
	size_t	const	N);

void	CAT(MPI_PREFIX,m_clo)(
	TYPE		* restrict a_MN,
	TYPE	const	* restrict v_N,
	size_t	const	M,
	size_t	const	N);

void	CAT(MPI_PREFIX,m_dot)(
	TYPE		* restrict a_MK,
	TYPE	const	* restrict b_MN,
	TYPE	const	* restrict c_NK,
	size_t	const	M,
	size_t	const	N,
	size_t	const	K);

void	CAT(MPI_PREFIX,m_euc_dis)(
	TYPE		* restrict a_MM,
	TYPE	const	* restrict b_MN,
	TYPE	const	* restrict c_MN,
	size_t	const	M,
	size_t	const	N);

void	CAT(MPI_PREFIX,m_fil)(
	TYPE		* restrict a_MN,
	TYPE	const	* restrict u_N,
	size_t	const	M,
	size_t	const	N);

void	CAT(MPI_PREFIX,m_lin)(
	TYPE 		* restrict a_MN,
	TYPE	const	* restrict min_M,
	TYPE	const	* restrict max_M,
	size_t	const	M,
	size_t	const	N);

TYPE	* CAT(MPI_PREFIX,m_mlc)(
	size_t	const	G,
	size_t	const	N);

void	CAT(MPI_PREFIX,m_mul)(
	TYPE		* restrict a_LN,
	TYPE	const	* restrict b_LN,
	TYPE	const	* restrict c_LN,
	size_t	const	G,
	size_t	const	N);

void	CAT(MPI_PREFIX,m_ord)(
	size_t 		* restrict a_MN,
	TYPE 	const	* restrict b_MN,
	bool	const	* restrict ord_M,
	size_t	const	M,
	size_t	const	N);

void	CAT(MPI_PREFIX,m_per)(
	TYPE 		* restrict a_MN,
	TYPE	const	* restrict b_MN,
	size_t	const	* restrict c_MN,
	size_t	const	M,
	size_t	const	N);

void	CAT(MPI_PREFIX,m_pri)(
	TYPE	const	* restrict a_MN,
	size_t	const	M,
	size_t	const	N);

void	CAT(MPI_PREFIX,m_rea_txt)(
	TYPE		* restrict a_LN,
	FILE		* file, 
	size_t	const	G,
	size_t	const	N);

void	CAT(MPI_PREFIX,m_rnd)(
	TYPE 		* restrict a_MN,
	TYPE	const	* restrict min_M,
	TYPE	const	* restrict max_M,
	int	const	seed,
	size_t	const	M,
	size_t	const	N);

void	CAT(MPI_PREFIX,m_sca)(
	TYPE		* restrict a_MN,
	TYPE	const	* restrict b_MN,
	TYPE	const	* restrict u_M,
	size_t	const	M,
	size_t	const	N);

void	CAT(MPI_PREFIX,m_shi)(
	TYPE		* restrict a_MN,
	TYPE	const	* restrict b_MN,
	TYPE	const	* restrict u_M,
	size_t	const	M,
	size_t	const	N);

void	CAT(MPI_PREFIX,m_sho)(
	TYPE		* restrict a_MN,
	TYPE	const	* restrict b_MN,
	TYPE	const	* restrict u_M,
	size_t	const	M,
	size_t	const	N);

void	CAT(MPI_PREFIX,m_srt)(
	TYPE		* restrict a_MN,
	TYPE	const	* restrict b_MN,
	bool	const	* restrict ord_M,
	size_t	const	M,
	size_t	const	N);

void	CAT(MPI_PREFIX,m_syh)(
	TYPE		* restrict a_NN,
	TYPE	const	* restrict v_S,
	size_t	const	S);

void	CAT(MPI_PREFIX,m_tra)(
	TYPE		* restrict a_NM,
	TYPE	const	* restrict b_MN,
	size_t	const	M,
	size_t	const	N);

void	CAT(MPI_PREFIX,m_wri_txt)(
	TYPE	const	* restrict a_LN,
	FILE		* file, 
	size_t	const	G,
	size_t	const	N);
