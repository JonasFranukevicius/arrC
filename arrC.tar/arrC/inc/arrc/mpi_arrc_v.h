#include <stdbool.h>
#include <stddef.h>
#include "arrc/arrc_macros.h"
#include "arrc/mpi_arrc_utils.h"
#include "arrc/arrc_v.h"

void	CAT(MPI_PREFIX,v_add)(
	TYPE 		* restrict w_N,
	TYPE	const	* restrict v_N,
	TYPE	const	* restrict u_N,
	size_t	const	N);

TYPE	* CAT(MPI_PREFIX,v_clc)(
	size_t	const	G);

void	CAT(MPI_PREFIX,v_cpy)(
	TYPE		* restrict w_N,
	TYPE	const	* restrict v_N,
	size_t	const	N);

void	CAT(MPI_PREFIX,v_div)(
	TYPE 		* restrict w_N,
	TYPE	const	* restrict v_N,
	TYPE	const	* restrict u_N,
	size_t	const	N);

void	CAT(MPI_PREFIX,v_euc_dis)(
	TYPE		* restrict w_M,
	TYPE	const	* restrict b_MN,
	TYPE	const	* restrict u_N,
	size_t	const	M,
	size_t	const	N);

void	CAT(MPI_PREFIX,v_euc_nrm)(
	TYPE		* restrict w_M,
	TYPE	const	* restrict b_MN,
	size_t	const	M,
	size_t	const	N);

void	CAT(MPI_PREFIX,v_fil)(
	TYPE 		* restrict w_N,
	TYPE	const	beta,
	size_t	const	N);

void	CAT(MPI_PREFIX,v_fun)(
	TYPE 		* restrict w_N,
	TYPE 	const	* restrict v_N,
	TYPE		(*fun)(TYPE const),
	size_t	const	N);

void	CAT(MPI_PREFIX,v_gat)(
	TYPE		* restrict w_G,
	TYPE	const	* restrict v_L,
	size_t	const	G);

void	CAT(MPI_PREFIX,v_lin)(
	TYPE 		* restrict w_N,
	TYPE	const	min,
	TYPE	const	max,
	size_t	const	N);

void	CAT(MPI_PREFIX,v_lin_stp)(
	TYPE		* restrict w_L,
	TYPE	const	* min_L,
	TYPE	const	* max_L,
	size_t	const	G,
	size_t	const	N);

void	CAT(MPI_PREFIX,v_mai)(
	size_t 		* restrict w_M,
	TYPE 	const	* restrict a_MN,
	size_t	const	M,
	size_t	const	N);

void	CAT(MPI_PREFIX,v_mav)(
	TYPE 		* restrict w_M,
	TYPE 	const	* restrict a_MN,
	size_t	const	M,
	size_t	const	N);

void	CAT(MPI_PREFIX,v_mii)(
	size_t		* restrict w_M,
	TYPE	const	* restrict a_MN,
	size_t	const	M,
	size_t	const	N);

void	CAT(MPI_PREFIX,v_miv)(
	TYPE 		* restrict w_M,
	TYPE 	const	* restrict a_MN,
	size_t	const	M,
	size_t	const	N);

TYPE	* CAT(MPI_PREFIX,v_mlc)(
	size_t	const	G);

void	CAT(MPI_PREFIX,v_mul)(
	TYPE		* restrict w_N,
	TYPE	const	* restrict v_N,
	TYPE	const	* restrict u_N,
	size_t	const	N);

void	CAT(MPI_PREFIX,v_ord)(
	size_t		* restrict w_N,
	TYPE	const	* restrict v_N,
	bool		order,
	size_t	const	N);

void	CAT(MPI_PREFIX,v_per)(
	TYPE		* restrict w_N,
	TYPE	const	* restrict v_N,
	size_t	const	* restrict u_N,
	size_t	const	N);

void	CAT(MPI_PREFIX,v_pri)(
	TYPE	const	* restrict w_N,
	size_t	const	N);

void	CAT(MPI_PREFIX,v_pro)(
	TYPE 		* restrict w_M,
	TYPE	const	* restrict b_MN,
	size_t	const	M,
	size_t	const	N);

void	CAT(MPI_PREFIX,v_rea_txt)(
	TYPE		* restrict w_L,
	FILE		* file,
	size_t	const	G);

void	CAT(MPI_PREFIX,v_rec)(
	TYPE 		* restrict w_N,
	TYPE	const	x,
	TYPE	const	* restrict v_N,
	size_t	const	N);

void	CAT(MPI_PREFIX,v_rnd)(
	TYPE 		* restrict w_N,
	TYPE	const	min,
	TYPE	const	max,
	int	const	seed,
	size_t	const	N);

void	CAT(MPI_PREFIX,v_sca)(
	TYPE 		* restrict w_N,
	TYPE	const	* restrict v_N,
	TYPE	const	alpha,
	size_t	const	N);

void	CAT(MPI_PREFIX,v_shf)(
	TYPE		* w_N,
	size_t		N);

void	CAT(MPI_PREFIX,v_shi)(
	TYPE 		* restrict w_N,
	TYPE	const	* restrict v_N,
	TYPE	const	beta,
	size_t	const	N);

void	CAT(MPI_PREFIX,v_sho)(
	TYPE 		* restrict w_N,
	TYPE	const	* restrict v_N,
	TYPE	const	beta,
	size_t	const	N);

void	CAT(MPI_PREFIX,v_srt)(
	TYPE 		* restrict w_N,
	TYPE	const	* restrict v_N,
	bool	const	order,
	size_t	const	N);

void	CAT(MPI_PREFIX,v_sub)(
	TYPE 		* restrict w_N,
	TYPE	const	* restrict v_N,
	TYPE	const	* restrict u_N,
	size_t	const	N);

void	CAT(MPI_PREFIX,v_sum)(
	TYPE 		* restrict w_N,
	TYPE	const	* restrict b_MN,
	size_t	const	M,
	size_t	const	N);

void	CAT(MPI_PREFIX,v_swp)(
	TYPE 		* restrict w_N,
	TYPE 		* restrict v_N,
	size_t	const	N);

void	CAT(MPI_PREFIX,v_wri_txt)(
	TYPE	const	* restrict w_L,
	FILE		* file,
	size_t	const	G);

void	CAT(MPI_PREFIX,v_syh)(
	TYPE		* restrict w_S,
	TYPE	const	* restrict b_NN,
	size_t	const	N);
