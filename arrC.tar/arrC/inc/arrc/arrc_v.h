#include <stdbool.h>
#include <stddef.h>
#include <stdio.h>
#include <math.h>
#include "arrc/arrc_macros.h"

#ifndef	NO_MACROS
#include "arrc/arrc_s.h"
#define	w_m	w_M[m]
#define	v_m	v_M[m]
#define	u_m	u_M[m]

#define	v_wi	v_N[w_i]
#define	v_wj	v_N[w_j]

#define	ord_m	ord_M[m]
#define	min_m	min_M[m]
#define	max_m	max_M[m]

#define	ord_n	ord_N[n]
#define	min_n	min_N[n]
#define	max_n	max_N[n]

#define mn	m * N + n
#define mN	m * N
#define	a_mN	&a_MN[mN]
#define	a_mn	a_MN[mn]
#define	b_mN	&b_MN[mN]
#define	b_mn	b_MN[mn]

#endif	/* NO_MACROS */

#ifndef	ARRC_SYH
#define	ARRC_SYH
static inline
int	N2S(
	int	N) {
	return N * (N - 1) / 2;
}

static inline
int	S2N(
	int	S) {
	return (1.0 + sqrt(1 + 8 * S)) / 2.0;
}

// ij[n,n]  -> s[n(n-1)/2] ???
/* ij          s
 * 00 01 02    00 01 02
 * .. 11 12 -> .. 03 04
 * .. .. 22    .. .. 05
 */
static inline
int	j2s(
	int	i,
	int	j) {
	return (j - i - 1);
}

static inline
int	i2s(
	int	i,
	int	N) {
	return -0.5 * i * (i - 2 * N + 1);
}

static inline
int	ij2s(
	int	i,
	int	j,
	int	N) {
	return i2s(i, N) + j2s(i, j);
}

/* s           i*
 * 00 01 02    0* 0* 0*
 * .. 03 04 -> .. 1* 1*
 * .. .. 05    .. .. 2*
 */
static inline
int	s2i(
	int	s,
	int	N) {
	return	(-0.5 * sqrt(4 * N * (N - 1) - 8 * s + 1) - 0.5) + N;
}

/* s           *j
 * 00 01 02    *0 *1 *2
 * .. 03 04 -> .. *1 *2
 * .. .. 05    .. .. *2
 */
static inline
int	s2j(
	int	s,
	int	N) {
	return	(s - i2s(s2i(s, N), N)) + s2i(s, N) + 1;
}

static inline
int	s2ij(
	int	s,
	int	N) {
	return s2i(s, N) * N + s2j(s, N);
}

static inline
int	s2ji(
	int	s,
	int	N) {
	return s2j(s, N) * N + s2i(s, N);
}
#endif	/* ARRC_SYH */

void	CAT(PREFIX,v_add)(
	TYPE 		* restrict w_N,
	TYPE	const	* restrict v_N,
	TYPE	const	* restrict u_N,
	size_t	const	N);

void	CAT(PREFIX,v_cpy)(
	TYPE		* restrict w_N,
	TYPE	const	* restrict v_N,
	size_t	const	N);

void	CAT(PREFIX,v_div)(
	TYPE 		* restrict w_N,
	TYPE	const	* restrict v_N,
	TYPE	const	* restrict u_N,
	size_t	const	N);

void	CAT(PREFIX,v_euc_dis)(
	TYPE		* restrict w_M,
	TYPE	const	* restrict b_MN,
	TYPE	const	* restrict u_N,
	size_t	const	M,
	size_t	const	N);

void	CAT(PREFIX,v_euc_dis_sqr)(
	TYPE		* restrict w_M,
	TYPE	const	* restrict b_MN,
	TYPE	const	* restrict u_N,
	size_t	const	M,
	size_t	const	N);

void	CAT(PREFIX,v_euc_nrm)(
	TYPE		* restrict w_M,
	TYPE	const	* restrict b_MN,
	size_t	const	M,
	size_t	const	N);

void	CAT(PREFIX,v_fil)(
	TYPE 		* restrict w_N,
	TYPE	const	beta,
	size_t	const	N);

void	CAT(PREFIX,v_fun)(
	TYPE 		* restrict w_N,
	TYPE 	const	* restrict v_N,
	TYPE		(*fun)(TYPE const),
	size_t	const	N);

void	CAT(PREFIX,v_lin)(
	TYPE 		* restrict w_N,
	TYPE	const	min,
	TYPE	const	max,
	size_t	const	N);

void	CAT(PREFIX,v_mai)(
	size_t 		* restrict w_M,
	TYPE 	const	* restrict a_MN,
	size_t	const	M,
	size_t	const	N);

void	CAT(PREFIX,v_mav)(
	TYPE 		* restrict w_M,
	TYPE 	const	* restrict a_MN,
	size_t	const	M,
	size_t	const	N);

void	CAT(PREFIX,v_mii)(
	size_t		* restrict w_M,
	TYPE	const	* restrict a_MN,
	size_t	const	M,
	size_t	const	N);

void	CAT(PREFIX,v_miv)(
	TYPE 		* restrict w_M,
	TYPE 	const	* restrict a_MN,
	size_t	const	M,
	size_t	const	N);

void	CAT(PREFIX,v_mul)(
	TYPE		* restrict w_N,
	TYPE	const	* restrict v_N,
	TYPE	const	* restrict u_N,
	size_t	const	N);

void	CAT(PREFIX,v_ord)(
	size_t		* restrict w_N,
	TYPE	const	* restrict v_N,
	bool		order,
	size_t	const	N);

void	CAT(PREFIX,v_per)(
	TYPE		* restrict w_N,
	TYPE	const	* restrict v_N,
	size_t	const	* restrict u_N,
	size_t	const	N);

void	CAT(PREFIX,v_pri)(
	TYPE	const	* restrict w_N,
	size_t	const	N);

void	CAT(PREFIX,v_pro)(
	TYPE 		* restrict w_M,
	TYPE	const	* restrict b_MN,
	size_t	const	M,
	size_t	const	N);

int	CAT(PREFIX,v_rea_txt)(
	TYPE		* restrict w_N,
	FILE		* file,
	size_t	const	N);

void	CAT(PREFIX,v_rec)(
	TYPE 		* restrict w_N,
	TYPE	const	x,
	TYPE	const	* restrict v_N,
	size_t	const	N);

void	CAT(PREFIX,v_rnd)(
	TYPE 		* restrict w_N,
	TYPE	const	min,
	TYPE	const	max,
	int	const	seed,
	size_t	const	N);

void	CAT(PREFIX,v_sca)(
	TYPE 		* restrict w_N,
	TYPE	const	* restrict v_N,
	TYPE	const	alpha,
	size_t	const	N);

void	CAT(PREFIX,v_shf)(TYPE *w_N, size_t N);

void	CAT(PREFIX,v_shi)(
	TYPE 		* restrict w_N,
	TYPE	const	* restrict v_N,
	TYPE	const	beta,
	size_t	const	N);

void	CAT(PREFIX,v_sho)(
	TYPE 		* restrict w_N,
	TYPE	const	* restrict v_N,
	TYPE	const	beta,
	size_t	const	N);

void	CAT(PREFIX,v_srt)(
	TYPE 		* restrict w_N,
	TYPE	const	* restrict v_N,
	bool	const	order,
	size_t	const	N);

void	CAT(PREFIX,v_sub)(
	TYPE 		* restrict w_N,
	TYPE	const	* restrict v_N,
	TYPE	const	* restrict u_N,
	size_t	const	N);

void	CAT(PREFIX,v_sum)(
	TYPE 		* restrict w_N,
	TYPE	const	* restrict b_MN,
	size_t	const	M,
	size_t	const	N);

void	CAT(PREFIX,v_swp)(
	TYPE 		* restrict w_N,
	TYPE 		* restrict v_N,
	size_t	const	N);

void	CAT(PREFIX,v_syh)(
	TYPE		* restrict w_S,
	TYPE	const	* restrict b_NN,
	size_t	const	N);

int	CAT(PREFIX,v_wri_txt)(
	TYPE	const	* restrict w_N,
	FILE		* file,
	size_t	const	N);
