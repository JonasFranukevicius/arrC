#include <stddef.h>
#include <mpi.h>
#include "arrc/arrc_macros.h"
#include "arrc/mpi_arrc_utils.h"
#include "arrc/arrc_t.h"

void	CAT(MPI_PREFIX,t_add)(
	TYPE		* restrict a,
	TYPE	const	* restrict b, const size_t * shp_b,
	TYPE	const	* restrict c, const size_t * shp_c,
	size_t	const	K,
	size_t	const	dis_axi);

TYPE	* CAT(MPI_PREFIX,t_clc)(
	size_t	const	* shp,
	size_t	const	K,
	size_t	const	dis_axi);

void	CAT(MPI_PREFIX,t_dec)(
	TYPE		* restrict a,
	TYPE	const	* restrict b, size_t const * shp_b,
	size_t	const	K,
	size_t	const	dis_axi);

void	CAT(MPI_PREFIX,t_div)(
	TYPE		* restrict a,
	TYPE	const	* restrict b, const size_t * shp_b,
	TYPE	const	* restrict c, const size_t * shp_c,
	size_t	const	K,
	size_t	const	dis_axi);

void	CAT(MPI_PREFIX,t_fil)(
	TYPE		* restrict a, const size_t * shp_a,
	TYPE	const	* restrict b, const size_t * shp_b,
	size_t		K,
	size_t	const	dis_axi);

void	CAT(MPI_PREFIX,t_fun)(
	TYPE		* restrict a,
	TYPE	const	* restrict b, size_t const * shp_b,
	TYPE		(** c)(TYPE), size_t const * shp_c,
	size_t	const	K,
	size_t	const	dis_axi);

void	CAT(MPI_PREFIX,t_gat)(
	TYPE		* restrict a,
	TYPE	const	* restrict b, size_t const * shp,
	size_t	const	K,
	size_t	const	dis_axi);

TYPE	* CAT(MPI_PREFIX,t_mlc)(
	size_t	const	* shp,
	size_t	const	K,
	size_t	const	dis_axi);

void	CAT(MPI_PREFIX,t_mul)(
	TYPE		* restrict a,
	TYPE	const	* restrict b, const size_t * shp_b,
	TYPE	const	* restrict c, const size_t * shp_c,
	size_t	const	K,
	size_t	const	dis_axi);

void	CAT(MPI_PREFIX,t_pro)(
	TYPE		* restrict a, const size_t * shp_a,
	TYPE	const	* restrict b, const size_t * shp_b,
	size_t	const	K,
	size_t	const	dis_axi);

void	CAT(MPI_PREFIX,t_sub)(
	TYPE		* restrict a,
	TYPE	const	* restrict b, const size_t * shp_b,
	TYPE	const	* restrict c, const size_t * shp_c,
	size_t	const	K,
	size_t	const	dis_axi);

void	CAT(MPI_PREFIX,t_sum)(
	TYPE		* restrict a, const size_t * shp_a,
	TYPE	const	* restrict b, const size_t * shp_b,
	size_t	const	K,
	size_t	const	dis_axi);
