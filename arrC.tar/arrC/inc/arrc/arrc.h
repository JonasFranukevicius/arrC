#ifndef ARRC_H
#define ARRC_H
#include <stddef.h>
#include <stdbool.h>
#include <stdint.h>

void arrc_seed(uint64_t seed);

#define NO_MACROS
/* ===== double specializations ===== */
#define	TYPE	double
#define	PREFIX	d
#include "arrc/arrc_s.h"
#include "arrc/arrc_v.h"
#include "arrc/arrc_m.h"
#include "arrc/arrc_t.h"
#undef	TYPE
#undef	PREFIX

/* ===== float specializations ===== */
#define	TYPE	float
#define	PREFIX	f
#include "arrc/arrc_s.h"
#include "arrc/arrc_v.h"
#include "arrc/arrc_m.h"
#include "arrc/arrc_t.h"
#undef	TYPE
#undef	PREFIX

/* ===== int specializations ===== */
#define	TYPE	int
#define	PREFIX	i
#include "arrc/arrc_s.h"
#include "arrc/arrc_v.h"
#include "arrc/arrc_m.h"
#include "arrc/arrc_t.h"
#undef	TYPE
#undef	PREFIX
#undef	NO_MACROS
#endif /* ARRC_H */
