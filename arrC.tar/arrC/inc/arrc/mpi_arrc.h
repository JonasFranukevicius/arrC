#ifndef MPI_ARRC_H
#define MPI_ARRC_H

#include <stddef.h>
#include <stdbool.h>

#define	NO_MACROS
/* ===== double specializations ===== */
#define	TYPE		double
#define	PREFIX		d
#define	MPI_TYPE	MPI_DOUBLE
#define	MPI_PREFIX	mpi_d
#define	MPI_TYPE_INT	MPI_DOUBLE_INT
#include "arrc/mpi_arrc_s.h"
#include "arrc/mpi_arrc_v.h"
#include "arrc/mpi_arrc_m.h"
#include "arrc/mpi_arrc_t.h"
#undef	TYPE
#undef	PREFIX
#undef	MPI_TYPE
#undef	MPI_PREFIX
#undef	MPI_TYPE_INT

/* ===== float specializations ===== */
#define	TYPE	float
#define	PREFIX	f
#define	MPI_TYPE	MPI_FLOAT
#define	MPI_PREFIX	mpi_f
#define	MPI_TYPE_INT	MPI_FLOAT_INT
#include "arrc/mpi_arrc_s.h"
#include "arrc/mpi_arrc_v.h"
#include "arrc/mpi_arrc_m.h"
#include "arrc/mpi_arrc_t.h"
#undef	TYPE
#undef	PREFIX
#undef	MPI_TYPE
#undef	MPI_PREFIX
#undef	MPI_TYPE_INT

/* ===== int specializations ===== */
#define	TYPE	int
#define	PREFIX	i
#define	MPI_TYPE	MPI_INT
#define	MPI_PREFIX	mpi_i
#define	MPI_TYPE_INT	MPI_2INT
#include "arrc/mpi_arrc_s.h"
#include "arrc/mpi_arrc_v.h"
#include "arrc/mpi_arrc_m.h"
#include "arrc/mpi_arrc_t.h"
#undef	TYPE
#undef	PREFIX
#undef	MPI_TYPE
#undef	MPI_PREFIX
#undef	MPI_TYPE_INT

#undef	NO_MACROS
#endif /* MPI_ARRC_H */
