#ifndef	MPI_ARRC_UTILS_H
#define	MPI_ARRC_UTILS_H
#include <mpi.h>

static inline
int	mpi_R() {
	static	int	val = -1;
	if (val == -1)
		MPI_Comm_size(MPI_COMM_WORLD, &val);
	return	val;
}

static inline
int	mpi_r() {
	static	int	val = -1;
	if (val == -1)
		MPI_Comm_rank(MPI_COMM_WORLD, &val);
	return	val;
}

#ifndef	NO_MACROS
#define K_MAX	8
#define	R	mpi_R()
#define	r	mpi_r()
#define	L	mpi_G2L(G, r)
#define	L_p	mpi_G2L(G, p)
#define	l2g	mpi_l2g(l, G, r)
#define	r2g	mpi_p2g(r, G)
#define	p2g	mpi_p2g(p, G)
#define	g2p	mpi_g2p(g, G)
#define	lN	l * N
#define	lM	l * M
#define	lm	l * M + m
#define	ln	l * N + n
#define	lG	l * G
#define	gN	l2g * N
#define	b_gN	&b_GN[gN]
#define	b_lN	&b_LN[lN]
#define	b_ln	b_LN[ln]
#define	a_lG	&a_LG[lG]
#define	a_gN	&a_LG[gN]
#define	a_lN	&a_LN[lN]
#define	a_lM	&a_LM[lM]
#define	a_lm	a_LM[lm]
#define	c_lN	&c_LN[lN]
#define	w_l	w_L[l]
#define	v_l	v_L[l]
#define	u_l	u_L[l]
#define	ord_l	ord_L[l]
#define	min_l	min_L[l]
#define	max_l	max_L[l]
#endif	/*NO_MACROS*/

static inline
size_t	mpi_G2L(
	size_t	const	G,
	int	const	p) {
	
	if (p < (G % mpi_R()))
		return	G / mpi_R() + 1;
	else
		return	G / mpi_R();
}

static inline
int	mpi_g2p(
	size_t	const	g,
	size_t	const	G) {
	
	if (g < (G % mpi_R()) * ((G / mpi_R()) + 1))
		return g / (G / mpi_R() + 1);
	else
		return (G % mpi_R()) 
			+ (g - (G % mpi_R()) * ((G / mpi_R()) + 1)) 
				/ (G / mpi_R());
}

static inline
size_t	mpi_p2g(
	int	const	p,
	size_t	const	G) {

	if (p < (G % mpi_R()))
		return p * (G / mpi_R() + 1);
	else
		return (p - G % mpi_R()) 
			* (G / mpi_R()) + (G % mpi_R()) * (G / mpi_R() + 1);
}

static inline
size_t	mpi_l2g(
	size_t	const	l,
	size_t	const	G,
	int	const	p) {

	return	l + mpi_p2g(p, G);
}

static inline
size_t	mpi_g2l(
	size_t	const	g,
	size_t	const	G) {

	if (mpi_g2p(g, G) < (G % mpi_R()))
		return g - mpi_g2p(g, G) * (G / mpi_R() + 1);
	else
		return g - (mpi_g2p(g, G) - G % mpi_R())
			* (G / mpi_R()) - (G % mpi_R()) * (G / mpi_R() + 1);
}

static
void	pv_shp_loc(
	size_t		* shp_loc,	// out, length K
	size_t	const	* shp,		// in,  length K
	size_t		K,
	size_t		dis_axi) {
	size_t	const	G = shp[dis_axi];

	for (size_t k = 0; k < K; ++k)
		if (k == dis_axi && G != 1)
			shp_loc[k] = mpi_G2L(G, mpi_r());
		else
			shp_loc[k] = shp[k];
}
#endif	/* MPI_ARRC_UTILS_H */
