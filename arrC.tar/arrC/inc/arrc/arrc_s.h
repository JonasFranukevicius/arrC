#include <stddef.h>
#include "arrc/arrc_macros.h"

#ifndef	NO_MACROS
#define	w_n	w_N[n]
#define	v_n	v_N[n]
#define	u_n	u_N[n]

#define	w_i	w_N[i]
#define	v_i	v_N[i]
#define	u_i	u_N[i]

#define	w_j	w_N[j]
#define	v_j	v_N[j]
#define	u_j	u_N[j]
#endif	/* NO_MACROS */


TYPE	CAT(PREFIX,s_dot)(
	TYPE	const	* restrict v_N,
	TYPE	const	* restrict u_N,
	size_t	const	N);

TYPE	CAT(PREFIX,s_euc_dis)(
	TYPE	const	* restrict v_N,
	TYPE	const	* restrict u_N,
	size_t	const	N);

TYPE	CAT(PREFIX,s_euc_dis_sqr)(
	TYPE	const	* restrict v_N,
	TYPE	const	* restrict u_N,
	size_t	const	N);

TYPE	CAT(PREFIX,s_euc_nrm)(
	TYPE	const	* restrict v_N,
	size_t	const	N);

TYPE	CAT(PREFIX,s_lin_stp)(
	TYPE	const	miv,
	TYPE	const	mav,
	size_t	const	N);

size_t	CAT(PREFIX,s_lin_stp_cnt)(
	TYPE	const	x,
	TYPE	const	miv,
	TYPE	const	mav,
	size_t	const	N);

size_t	CAT(PREFIX,s_mai)(
	TYPE 	const	* restrict v_N,
	size_t	const	N);

TYPE	CAT(PREFIX,s_mav)(
	TYPE 	const	* restrict v_N,
	size_t	const	N);

size_t	CAT(PREFIX,s_mii)(
	TYPE 	const	* restrict v_N,
	size_t	const	N);

TYPE	CAT(PREFIX,s_miv)(
	TYPE 	const	* restrict v_N,
	size_t	const	N);

TYPE	CAT(PREFIX,s_pro)(
	TYPE	const	* restrict v_N,
	size_t	const	N);

TYPE	CAT(PREFIX,s_rnd)(
	TYPE	const	min,
	TYPE	const	max);

TYPE	CAT(PREFIX,s_sum)(
	TYPE	const	* restrict v_N,
	size_t	const	N);

void	CAT(PREFIX,s_swp)(
	TYPE * x,
	TYPE * y); 
