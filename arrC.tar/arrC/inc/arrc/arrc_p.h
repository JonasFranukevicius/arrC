#ifndef	ARRC_P_H
#define	ARRC_P_H
#include <stdbool.h>
#include <stddef.h>

size_t	ps_dot(
	size_t	const	* restrict v_N,
	size_t	const	* restrict u_N,
	size_t	const	N);

size_t	ps_euc_dis(
	size_t	const	* restrict v_N,
	size_t	const	* restrict u_N,
	size_t	const	N);

size_t	ps_euc_nrm(
	size_t	const	* restrict v_N,
	size_t	const	N);

size_t	ps_lin_stp(
	size_t	const	miv,
	size_t	const	mav,
	size_t	const	N);

size_t	ps_lin_stp_cnt(
	size_t	const	x,
	size_t	const	miv,
	size_t	const	mav,
	size_t	const	N);

size_t	ps_mai(
	size_t 	const	* restrict v_N,
	size_t	const	N);

size_t	ps_mav(
	size_t 	const	* restrict v_N,
	size_t	const	N);

size_t	ps_mii(
	size_t 	const	* restrict v_N,
	size_t	const	N);

size_t	ps_miv(
	size_t 	const	* restrict v_N,
	size_t	const	N);

size_t	ps_pro(
	size_t	const	* restrict v_N,
	size_t	const	N);

size_t	ps_sum(
	size_t	const	* restrict v_N,
	size_t	const	N);

void	ps_swp(
	size_t * x,
	size_t * y); 

void	pv_add(
	size_t 		* restrict w_N,
	size_t	const	* restrict v_N,
	size_t	const	* restrict u_N,
	size_t	const	N);

void	pv_cpy(
	size_t		* restrict w_N,
	size_t	const	* restrict v_N,
	size_t	const	N);

void	pv_div(
	size_t 		* restrict w_N,
	size_t	const	* restrict v_N,
	size_t	const	* restrict u_N,
	size_t	const	N);

void	pv_euc_dis(
	size_t		* restrict w_M,
	size_t	const	* restrict b_MN,
	size_t	const	* restrict u_N,
	size_t	const	M,
	size_t	const	N);

void	pv_euc_nrm(
	size_t		* restrict w_M,
	size_t	const	* restrict b_MN,
	size_t	const	M,
	size_t	const	N);

void	pv_fil(
	size_t 		* restrict w_N,
	size_t	const	beta,
	size_t	const	N);

void	pv_fun(
	size_t 		* restrict w_N,
	size_t 	const	* restrict v_N,
	size_t		(*fun)(size_t const),
	size_t	const	N);

void	pv_lin(
	size_t 		* restrict w_N,
	size_t	const	min,
	size_t	const	max,
	size_t	const	N);

void	pv_mai(
	size_t 		* restrict w_M,
	size_t 	const	* restrict a_MN,
	size_t	const	M,
	size_t	const	N);

void	pv_mav(
	size_t 		* restrict w_M,
	size_t 	const	* restrict a_MN,
	size_t	const	M,
	size_t	const	N);

void	pv_mii(
	size_t		* restrict w_M,
	size_t	const	* restrict a_MN,
	size_t	const	M,
	size_t	const	N);

void	pv_miv(
	size_t 		* restrict w_M,
	size_t 	const	* restrict a_MN,
	size_t	const	M,
	size_t	const	N);

void	pv_mul(
	size_t		* restrict w_N,
	size_t	const	* restrict v_N,
	size_t	const	* restrict u_N,
	size_t	const	N);

void	pv_ord(
	size_t		* restrict w_N,
	size_t	const	* restrict v_N,
	bool		order,
	size_t	const	N);

void	pv_per(
	size_t		* restrict w_N,
	size_t	const	* restrict v_N,
	size_t	const	* restrict u_N,
	size_t	const	N);

void	pv_pri(
	size_t	const	* restrict w_N,
	size_t	const	N);

void	pv_pro(
	size_t 		* restrict w_M,
	size_t	const	* restrict b_MN,
	size_t	const	M,
	size_t	const	N);

void	pv_rec(
	size_t 		* restrict w_N,
	size_t	const	x,
	size_t	const	* restrict v_N,
	size_t	const	N);

void	pv_rnd(
	size_t 		* restrict w_N,
	size_t	const	min,
	size_t	const	max,
	int	const	seed,
	size_t	const	N);

void	pv_sca(
	size_t 		* restrict w_N,
	size_t	const	* restrict v_N,
	size_t	const	alpha,
	size_t	const	N);

void	pv_shf(size_t *w_N, size_t N);

void	pv_shi(
	size_t 		* restrict w_N,
	size_t	const	* restrict v_N,
	size_t	const	beta,
	size_t	const	N);

void	pv_sho(
	size_t 		* restrict w_N,
	size_t	const	* restrict v_N,
	size_t	const	beta,
	size_t	const	N);

void	pv_srt(
	size_t 		* restrict w_N,
	size_t	const	* restrict v_N,
	bool	const	order,
	size_t	const	N);

void	pv_sub(
	size_t 		* restrict w_N,
	size_t	const	* restrict v_N,
	size_t	const	* restrict u_N,
	size_t	const	N);

void	pv_sum(
	size_t 		* restrict w_N,
	size_t	const	* restrict b_MN,
	size_t	const	M,
	size_t	const	N);

void	pv_swp(
	size_t 		* restrict w_N,
	size_t 		* restrict v_N,
	size_t	const	N);

void	pv_syh(
	size_t		* restrict w_S,
	size_t	const	* restrict b_NN,
	size_t	const	N);

#endif	/* ARRC_P_H */
