#include <stddef.h>
#include <stdbool.h>
#include <stdio.h>
#include "arrc/arrc_macros.h"

#ifndef	NO_MACROS
#include "arrc/arrc_v.h"
#define nm	n * M + m
#define mk	m * K + k
#define mM	m * M
#define nk	n * K + k
#define kn	k * N + n
#define km	k * M + m
#define in	i * N + n
#define jn	j * N + n
#define mi	m * N + i
#define mj	m * N + j

#define	c_mN	&c_MN[mN]
#define	c_nk	c_NK[nk]
#define	a_mM	&a_MM[mM]

#define	a_nm	a_NM[nm]
#define	a_mk	a_MK[mk]

#define	a_nn	a_NN[n * N + n]

#endif	/* NO_MACROS */

void	CAT(PREFIX,m_clo)(
	TYPE		* restrict a_MN,
	TYPE	const	* restrict v_N,
	size_t	const	M,
	size_t	const	N);

void	CAT(PREFIX,m_dia)(
	TYPE		* restrict a_NN,
	TYPE	const	* restrict v_N,
	size_t	const	N);

void	CAT(PREFIX,m_dot)(
	TYPE		* restrict a_MK,
	TYPE	const	* restrict b_MN,
	TYPE	const	* restrict c_NK,
	size_t	const	M,
	size_t	const	N,
	size_t	const	K);

void	CAT(PREFIX,m_euc_dis)(
	TYPE		* restrict a_MM,
	TYPE	const	* restrict b_MN,
	TYPE	const	* restrict c_MN,
	size_t	const	M,
	size_t	const	N);

void	CAT(PREFIX,m_euc_dis_sqr)(
	TYPE		* restrict a_MM,
	TYPE	const	* restrict b_MN,
	TYPE	const	* restrict c_MN,
	size_t	const	M,
	size_t	const	N);

void	CAT(PREFIX,m_fil)(
	TYPE		* restrict a_MN,
	TYPE	const	* restrict u_N,
	size_t	const	M,
	size_t	const	N);

void	CAT(PREFIX,m_lin)(
	TYPE 		* restrict a_MN,
	TYPE	const	* restrict min_M,
	TYPE	const	* restrict max_M,
	size_t	const	M,
	size_t	const	N);

void	CAT(PREFIX,m_ord)(
	size_t 		* restrict a_MN,
	TYPE 	const	* restrict b_MN,
	bool	const	* restrict ord_M,
	size_t	const	M,
	size_t	const	N);

void	CAT(PREFIX,m_per)(
	TYPE 		* restrict a_MN,
	TYPE	const	* restrict b_MN,
	size_t	const	* restrict c_MN,
	size_t	const	M,
	size_t	const	N);

void	CAT(PREFIX,m_pri)(
	TYPE	const	* restrict a_MN,
	size_t	const	M,
	size_t	const	N);

int	CAT(PREFIX,m_rea_txt)(
	TYPE		* restrict a_MN,
	FILE		* file,
	size_t	const	M,
	size_t	const	N);

void	CAT(PREFIX,m_rnd)(
	TYPE 		* restrict a_MN,
	TYPE	const	* restrict min_M,
	TYPE	const	* restrict max_M,
	int	const	seed,
	size_t	const	M,
	size_t	const	N);

void	CAT(PREFIX,m_sca)(
	TYPE		* restrict a_MN,
	TYPE	const	* restrict b_MN,
	TYPE	const	* restrict u_M,
	size_t	const	M,
	size_t	const	N);

void	CAT(PREFIX,m_shi)(
	TYPE		* restrict a_MN,
	TYPE	const	* restrict b_MN,
	TYPE	const	* restrict u_M,
	size_t	const	M,
	size_t	const	N);

void	CAT(PREFIX,m_sho)(
	TYPE		* restrict a_MN,
	TYPE	const	* restrict b_MN,
	TYPE	const	* restrict u_M,
	size_t	const	M,
	size_t	const	N);

void	CAT(PREFIX,m_srt)(
	TYPE		* restrict a_MN,
	TYPE	const	* restrict b_MN,
	bool	const	* restrict ord_M,
	size_t	const	M,
	size_t	const	N);

void	CAT(PREFIX,m_syh)(
	TYPE		* restrict a_NN,
	TYPE	const	* restrict v_S,
	size_t	const	S);

void	CAT(PREFIX,m_tra)(
	TYPE		* restrict a_NM,
	TYPE	const	* restrict b_MN,
	size_t	const	M,
	size_t	const	N);

int	CAT(PREFIX,m_wri_txt)(
	TYPE	const	* restrict a_MN,
	FILE		* file,
	size_t	const	M,
	size_t	const	N);
